# Bun Playground — Practice Guide

One minimal Bun setup for practicing **API routes, vanilla DOM/TS, and React (TSX)**.
No Vite/Webpack/Express — `Bun.serve()` bundles the frontend and serves the API.

## Setup (once)

```bash
bun install
```

## Run

| Command | What runs | Open |
| --- | --- | --- |
| `bun run dev` | fullstack server (React + vanilla + API) with HMR | http://localhost:3000 |
| `bun run scratch` | pure TS in the terminal, re-runs on save | — |
| `bun run typecheck` | `tsc --noEmit` (Bun does NOT type-check on its own) | — |
| `bun run build` | production AOT bundle into `dist/` | — |

`bun run dev` serves three things at once:
- `/` → React app ([app.tsx](app.tsx))
- `/page` → vanilla HTML/TS/CSS ([page.ts](page.ts))
- `/api/*` → API routes ([server.ts](server.ts))

---

## How to do an exercise

> Rule (from your rehab plan): **AI off for the first draft.** Write it by hand,
> run it, then ask for a review.

### 1. Pure logic / algorithm — `scratch.ts`

Best for debounce, throttle, deep-clone, array/string transforms, TS types.

1. Open [scratch.ts](scratch.ts), delete the sample, write your solution + a few `console.log` test cases.
2. Run it (auto-reruns on every save):
   ```bash
   bun run scratch
   ```
3. Read the output in the terminal. No browser needed.

### 2. Vanilla DOM / TS — `page.ts` (+ `page.html`, `page.css`)

Best for form + localStorage, star rating, tabs, accordion, click handlers.

1. Add the markup you need in [page.html](page.html) (inside `<body>`).
2. Write the logic by hand in [page.ts](page.ts) — `document.querySelector`,
   `addEventListener`, DOM updates. Style in [page.css](page.css).
3. Run and open the page:
   ```bash
   bun run dev
   ```
   → http://localhost:3000/page  (edits hot-reload)

### 3. React component — `app.tsx`

Best for stateful UI: counter, list + add/remove, controlled inputs, tabs.

1. Write your component in [app.tsx](app.tsx) (use `useState`/`useEffect`).
2. Run and open:
   ```bash
   bun run dev
   ```
   → http://localhost:3000  (edits hot-reload)

### 4. API route — `server.ts`

Best for fetch + render, search, inline edit, CRUD practice.

1. Add a route to the `routes` object in [server.ts](server.ts):
   ```ts
   "/api/users": {
     GET() { return Response.json([{ id: 1, name: "Ada" }]); },
     async POST(req) {
       const body = await req.json();
       return Response.json(body, { status: 201 });
     },
   },
   // dynamic param:
   "/api/users/:id": (req) => Response.json({ id: req.params.id }),
   ```
2. Call it from the frontend (same origin, no CORS):
   ```ts
   const users = await fetch("/api/users").then((r) => r.json());
   ```
3. Run `bun run dev`. Browser `console.log`s also stream to your terminal.

---

## Typical full exercise (API → fetch → render)

A realistic interview drill ties all layers together:

1. **API** in `server.ts`: `GET /api/users` returns a list, `POST` adds one.
2. **React** in `app.tsx`: `fetch` the list, render it, add a form that POSTs.
3. **Verify** in the browser, watch logs in the terminal.

```diagram
╭ server.ts ╮   fetch("/api/users")   ╭ app.tsx ╮   render   ╭ browser ╮
│  routes   │◀───────────────────────│  React  │──────────▶│  :3000  │
╰───────────╯                         ╰─────────╯            ╰─────────╯
```

## Files

```
bun-playground/
├─ server.ts      # Bun.serve: routes for React, vanilla page, and API
├─ react.html     # React entry → app.tsx
├─ app.tsx        # React exercises
├─ page.html      # vanilla entry → page.ts + page.css
├─ page.ts        # vanilla DOM/TS exercises
├─ page.css       # styles for the vanilla page
├─ scratch.ts     # pure logic/algorithm exercises
├─ tsconfig.json
└─ package.json
```
