import { serve } from "bun";
import react from "./react.html";
import page from "./page.html";

const server = serve({
  port: 3100,
  routes: {
    // Frontend routes — Bun bundles the <script>/<link> tags in each HTML file.
    "/": react,
    "/page": page,

    // API route — same server, no CORS, no second process.
    "/api/hello": {
      GET() {
        return Response.json({ message: "Hello from the Bun server" });
      },
    },
  },

  // Dev mode: detailed errors, hot reload, and browser console → terminal.
  development: { hmr: true, console: true },
});

console.log(`Listening on ${server.url}`);
