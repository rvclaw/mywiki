# Lesson 03: The Message Router

Up until now, we have a single agent. But production systems like
Antigravity, Pi, and OpenCode run **multiple agents concurrently** — an
orchestrator delegates work to subagents, each running their own loop.

They communicate through a **Message Router** — a central mailbox system.
Each agent has an inbox. When Agent A sends a message to Agent B, the router
delivers it. If Agent B is sleeping (no work to do), the router **wakes it up**.

This is the exact pattern that powers:
- Antigravity's `invoke_subagent` / `send_message` tools
- Pi's `event-bus.ts`
- Distributed systems like Kafka or Redis PubSub (but in-memory for us)

## 1. The Router (`src/MessageRouter.ts`)

```typescript
// src/MessageRouter.ts
import type { Message } from './types.ts';

/**
 * Central message router for agent-to-agent communication.
 *
 * Key design: agents call waitForMessages() which returns a Promise.
 * If there are no messages, the Promise suspends (the agent sleeps).
 * When routeMessage() delivers a message, it resolves the Promise
 * (the agent wakes up).
 *
 * This means sleeping agents consume ZERO CPU.
 */
export class MessageRouter {

  // Each agent gets an inbox (queue of pending messages)
  private inboxes = new Map<string, Message[]>();

  // When an agent is sleeping, we store its Promise resolve function here
  private wakeLocks = new Map<string, (messages: Message[]) => void>();

  /**
   * Register an agent so it can receive messages.
   */
  registerAgent(conversationId: string): void {
    if (!this.inboxes.has(conversationId)) {
      this.inboxes.set(conversationId, []);
    }
  }

  /**
   * Deliver a message to a specific agent.
   * If the agent is sleeping, wake it up immediately.
   */
  routeMessage(message: Message): void {
    const inbox = this.inboxes.get(message.recipientId);
    if (!inbox) {
      console.warn(`[Router] No inbox for ${message.recipientId}, dropping message`);
      return;
    }

    inbox.push(message);

    // Is the recipient sleeping?
    const wakeLock = this.wakeLocks.get(message.recipientId);
    if (wakeLock) {
      // Yes! Drain the inbox and resolve the Promise
      const pending = [...inbox];
      inbox.length = 0;
      this.wakeLocks.delete(message.recipientId);
      wakeLock(pending);  // <-- This line wakes up the agent
    }
  }

  /**
   * Called by an agent when it has nothing to do.
   *
   * If messages are already queued  → returns them immediately
   * If inbox is empty              → returns a Promise that suspends
   *                                   until routeMessage() delivers one
   */
  async waitForMessages(conversationId: string): Promise<Message[]> {
    const inbox = this.inboxes.get(conversationId);
    if (!inbox) throw new Error(`Agent ${conversationId} not registered`);

    // Fast path: messages already waiting
    if (inbox.length > 0) {
      const messages = [...inbox];
      inbox.length = 0;
      return messages;
    }

    // Slow path: go to sleep
    return new Promise((resolve) => {
      this.wakeLocks.set(conversationId, resolve);
    });
  }
}
```

## 2. How Agents Use the Router

```typescript
// Example: An orchestrator spawning a subagent

const router = new MessageRouter();
router.registerAgent('orchestrator');
router.registerAgent('subagent-1');

// The subagent loop (runs in the background)
async function subagentLoop() {
  while (true) {
    // Sleep until the orchestrator sends work
    const messages = await router.waitForMessages('subagent-1');

    for (const msg of messages) {
      console.log(`[Subagent] Got task: ${msg.content}`);
      // ... do work ...

      // Report back to the orchestrator
      router.routeMessage({
        senderId: 'subagent-1',
        recipientId: 'orchestrator',
        content: 'Task complete!',
        priority: 'HIGH',
        timestamp: Date.now(),
      });
    }
  }
}

// Start the subagent (don't await — it runs forever)
subagentLoop();

// Send it a task
router.routeMessage({
  senderId: 'orchestrator',
  recipientId: 'subagent-1',
  content: 'Please install react and next',
  priority: 'HIGH',
  timestamp: Date.now(),
});
```

## Why This Works (The Promise Trick)

The magic is in `waitForMessages()`. When the inbox is empty:

```typescript
return new Promise((resolve) => {
  this.wakeLocks.set(conversationId, resolve);
});
```

This creates a Promise that **never resolves on its own**. The agent's
`await` pauses execution right there. Node.js releases the thread.
CPU usage = 0%.

Later, when `routeMessage()` delivers a message:

```typescript
wakeLock(pending);  // calls resolve(messages)
```

The Promise resolves. The agent's `await` returns. The agent wakes up.

This is how Antigravity handles 50+ concurrent subagents on a laptop
without melting your CPU.

## What You Just Built

```
src/
├── MessageRouter.ts        # Message routing + sleep/wake (THIS lesson)
├── agent/
│   ├── run.ts              # Agent loop (lesson 02)
│   └── system/prompt.ts
├── executeTool.ts
├── tools/
│   ├── index.ts
│   ├── file.ts
│   └── shell.ts
└── types.ts
```

## Next: Lesson 04

We will build the **Background Task Manager** — replacing our synchronous
`execSync` shell tool with an async `child_process.spawn` that runs OS
commands in the background and routes the output back through the router.
