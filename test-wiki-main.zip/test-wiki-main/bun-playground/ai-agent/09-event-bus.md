# Lesson 09: The Event Bus (Observable Engine)

So far, our `AgentCallbacks` pattern works well for a single agent talking
to a single frontend. But in a multi-agent system with subagents, background
tasks, and complex tool executions, we need something richer.

Pi solves this with an **Event Bus** — a pub/sub system that broadcasts
every internal engine event to all subscribers. The frontend subscribes
to the events it cares about and renders them.

Pi's implementation (`event-bus.ts`) is beautifully simple — just 34 lines
wrapping Node's `EventEmitter` with error-safe handlers and teardown.

## 1. The Event Bus (`src/EventBus.ts`)

```typescript
// src/EventBus.ts
import { EventEmitter } from 'events';

/**
 * Event types the engine emits.
 * Any frontend can subscribe to these.
 */
export type EngineEvent =
  // Agent lifecycle
  | { type: 'agent:started'; agentId: string; role: string }
  | { type: 'agent:idle'; agentId: string }
  | { type: 'agent:killed'; agentId: string }

  // LLM streaming
  | { type: 'token'; agentId: string; text: string }
  | { type: 'response:complete'; agentId: string; text: string }

  // Tool execution
  | { type: 'tool:start'; agentId: string; toolName: string; args: unknown }
  | { type: 'tool:end'; agentId: string; toolName: string; result: string }
  | { type: 'tool:approval_needed'; agentId: string; toolName: string; args: unknown }

  // Background tasks
  | { type: 'task:started'; taskId: string; command: string }
  | { type: 'task:output'; taskId: string; chunk: string }
  | { type: 'task:finished'; taskId: string; exitCode: number | null }

  // Subagent lifecycle
  | { type: 'subagent:spawned'; parentId: string; childId: string; role: string }
  | { type: 'subagent:finished'; childId: string; parentId: string }

  // Messages
  | { type: 'message:routed'; senderId: string; recipientId: string; preview: string };

/**
 * A pub/sub event bus for engine-wide events.
 *
 * Pattern: pi-main/packages/coding-agent/src/core/event-bus.ts
 *
 * Pi's implementation wraps EventEmitter with:
 * 1. Error-safe handlers (catch errors so one bad subscriber doesn't crash the bus)
 * 2. Teardown functions (each .on() returns an unsubscribe function)
 * 3. A clear() method to reset all listeners on shutdown
 */
export interface EventBus {
  emit(event: EngineEvent): void;
  on(type: string, handler: (event: EngineEvent) => void): () => void;
  clear(): void;
}

export function createEventBus(): EventBus {
  const emitter = new EventEmitter();

  return {
    emit: (event) => {
      // Emit on both the specific channel AND a wildcard '*' channel
      emitter.emit(event.type, event);
      emitter.emit('*', event);
    },

    on: (type, handler) => {
      // Wrap handler with error catching (Pi's pattern)
      const safeHandler = async (event: EngineEvent) => {
        try {
          await handler(event);
        } catch (err) {
          console.error(`[EventBus] Handler error on "${type}":`, err);
        }
      };

      emitter.on(type, safeHandler);

      // Return an unsubscribe function (Pi's teardown pattern)
      return () => emitter.off(type, safeHandler);
    },

    clear: () => {
      emitter.removeAllListeners();
    },
  };
}
```

## 2. Wiring the Event Bus into the Engine

We update `MessageRouter`, `TaskManager`, and `SubagentManager` to emit events.

### MessageRouter (updated)

```typescript
// In MessageRouter.ts — add event bus
constructor(private eventBus: EventBus) {}

routeMessage(message: Message): void {
  // ... existing delivery logic ...

  // Broadcast to all subscribers
  this.eventBus.emit({
    type: 'message:routed',
    senderId: message.senderId,
    recipientId: message.recipientId,
    preview: message.content.slice(0, 200),
  });
}
```

### TaskManager (updated)

```typescript
// In TaskManager.ts — add event bus
constructor(private router: MessageRouter, private eventBus: EventBus) {}

executeBackground(agentId: string, command: string, cwd: string): string {
  // ... existing spawn logic ...

  this.eventBus.emit({ type: 'task:started', taskId, command });

  child.stdout?.on('data', (chunk: Buffer) => {
    const text = chunk.toString();
    task.logs += text;
    this.eventBus.emit({ type: 'task:output', taskId, chunk: text });
  });

  child.on('exit', (code) => {
    this.eventBus.emit({ type: 'task:finished', taskId, exitCode: code });
    // ... existing route message logic ...
  });
}
```

### SubagentManager (updated)

```typescript
// In SubagentManager.ts — add event bus
constructor(
  private router: MessageRouter,
  private taskManager: TaskManager,
  private eventBus: EventBus,
) {}

async spawn(...): Promise<string> {
  // ... existing spawn logic ...

  this.eventBus.emit({
    type: 'subagent:spawned',
    parentId,
    childId: conversationId,
    role,
  });
}
```

## 3. The TUI Subscribing to Events

Now the TUI can render rich, real-time information about everything
happening in the engine:

```typescript
// In the TUI or frontend:
const eventBus = createEventBus();

// Show a spinner when any task is running
eventBus.on('task:started', (e) => {
  if (e.type === 'task:started') {
    renderSpinner(`Running: ${e.command}`);
  }
});

// Show live output from background commands
eventBus.on('task:output', (e) => {
  if (e.type === 'task:output') {
    appendToLogPanel(e.chunk);
  }
});

// Show subagent activity
eventBus.on('subagent:spawned', (e) => {
  if (e.type === 'subagent:spawned') {
    renderStatusBar(`🚀 Spawned: ${e.role}`);
  }
});

// Subscribe to ALL events for debugging
const unsub = eventBus.on('*', (e) => {
  console.debug(`[DEBUG] ${e.type}`, e);
});

// Later, to stop listening:
unsub();
```

## 4. Event Bus vs. Message Router — When to Use Which

| | Message Router | Event Bus |
|---|---|---|
| **Purpose** | Agent-to-agent communication | Engine observability |
| **Delivery** | Targeted (one recipient) | Broadcast (all subscribers) |
| **Buffering** | Yes (inbox queue) | No (fire and forget) |
| **Suspension** | Yes (waitForMessages) | No (subscribers must be active) |
| **Use case** | Subagent sends result to parent | TUI renders tool progress |

Think of the **Message Router** as a mailbox (private, reliable, queued)
and the **Event Bus** as a loudspeaker (public, best-effort, real-time).

## What You Just Built

```
src/
├── EventBus.ts              # Pub/sub event system (THIS lesson)
├── SubagentManager.ts       # (updated with events)
├── orchestrator.ts
├── tools/
│   ├── subagent.ts
│   ├── index.ts
│   ├── file.ts
│   └── shell.ts
├── agent/
│   ├── context/ ...
│   ├── run.ts
│   └── system/prompt.ts
├── TranscriptLogger.ts
├── TaskManager.ts           # (updated with events)
├── MessageRouter.ts         # (updated with events)
├── executeTool.ts
└── types.ts
```

## The Complete Architecture

```
                              ┌──────────────┐
                              │  Event Bus   │  (broadcast)
                              │ (pub/sub)    │
                              └──────┬───────┘
                                     │ emits events
           ┌─────────────────────────┼─────────────────────────┐
           │                         │                         │
    ┌──────▼──────┐          ┌───────▼──────┐          ┌───────▼──────┐
    │    TUI      │          │   Web UI     │          │  Log File    │
    │  (Ink)      │          │  (WebSocket) │          │  (debug)     │
    └─────────────┘          └──────────────┘          └──────────────┘

                              ┌──────────────┐
                              │ Msg Router   │  (point-to-point)
                              │ (mailbox)    │
                              └──────┬───────┘
                                     │ delivers messages
           ┌─────────────────────────┼─────────────────────────┐
           │                         │                         │
    ┌──────▼──────┐          ┌───────▼──────┐          ┌───────▼──────┐
    │ Orchestrator│          │ Subagent A   │          │ Subagent B   │
    │  (sleeping) │          │ (running)    │          │  (idle)      │
    └─────────────┘          └──────────────┘          └──────────────┘
```

This is the complete, production-grade architecture that powers
Antigravity, Pi, and every serious agentic runtime.
