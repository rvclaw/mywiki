# Lesson 06: Frontend Integration (TUI & Web)

The engine is headless. It doesn't know how its output is rendered.
The **agents-v2 course** proves this beautifully — the agent loop (`run.ts`)
accepts an `AgentCallbacks` object. The TUI (`App.tsx`) provides the
implementations. If you swap in a WebSocket server instead, the same
engine powers a web app.

This lesson shows both frontends.

## 1. TUI with Ink (React for the Terminal)

The agents-v2 course uses **Ink** — a library that lets you write terminal
UIs using React components. `<Box>` is like `<div>`, `<Text>` is like `<span>`.

### `src/ui/App.tsx`

```tsx
// src/ui/App.tsx
import React, { useState, useCallback } from 'react';
import { Box, Text, useApp } from 'ink';
import TextInput from 'ink-text-input';
import type { ModelMessage } from 'ai';
import { runAgent } from '../agent/run.ts';
import type { AgentCallbacks } from '../types.ts';

export function App() {
  const { exit } = useApp();
  const [messages, setMessages] = useState<{ role: string; text: string }[]>([]);
  const [history, setHistory] = useState<ModelMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [streaming, setStreaming] = useState('');
  const [input, setInput] = useState('');

  const handleSubmit = useCallback(async (userInput: string) => {
    if (userInput === 'exit') { exit(); return; }

    setMessages(prev => [...prev, { role: 'user', text: userInput }]);
    setIsLoading(true);
    setStreaming('');
    setInput('');

    const callbacks: AgentCallbacks = {
      // Stream tokens to the terminal in real-time
      onToken: (token) => setStreaming(prev => prev + token),

      onToolCallStart: (name) => {
        setMessages(prev => [...prev, { role: 'tool', text: `⚙️  ${name}...` }]);
      },

      onToolCallEnd: (name, result) => {
        setMessages(prev => [...prev, { role: 'tool', text: `✅ ${name} done` }]);
      },

      onComplete: (response) => {
        if (response) {
          setMessages(prev => [...prev, { role: 'assistant', text: response }]);
        }
        setStreaming('');
      },

      // HITL: Ask the user before running dangerous tools
      onToolApproval: async (name, args) => {
        // In a real TUI, you'd render a confirmation prompt here
        // For simplicity, auto-approve all tools
        return true;
      },
    };

    try {
      const newHistory = await runAgent(userInput, history, callbacks);
      setHistory(newHistory);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'error', text: String(err) }]);
    } finally {
      setIsLoading(false);
    }
  }, [history, exit]);

  return (
    <Box flexDirection="column" padding={1}>
      <Text bold color="cyan">🤖 Agent Engine</Text>
      <Text dimColor>(type "exit" to quit)</Text>

      <Box flexDirection="column" marginY={1}>
        {messages.map((msg, i) => (
          <Box key={i} marginBottom={1}>
            <Text color={msg.role === 'user' ? 'yellow' : msg.role === 'assistant' ? 'green' : 'gray'}>
              {msg.role === 'user' ? '› You: ' : '› Agent: '}{msg.text}
            </Text>
          </Box>
        ))}

        {streaming && (
          <Text color="green">› Agent: {streaming}▌</Text>
        )}

        {isLoading && !streaming && <Text color="gray">Thinking...</Text>}
      </Box>

      {!isLoading && (
        <Box>
          <Text color="yellow">› </Text>
          <TextInput value={input} onChange={setInput} onSubmit={handleSubmit} />
        </Box>
      )}
    </Box>
  );
}
```

### `src/index.tsx` (Entry Point)

```tsx
// src/index.tsx
import React from 'react';
import { render } from 'ink';
import { App } from './ui/App.tsx';

render(React.createElement(App));
```

---

## 2. Web App with WebSockets

Same engine, different frontend. Instead of Ink, we stream agent events
over a WebSocket to a browser.

### `src/server.ts`

```typescript
// src/server.ts
import { WebSocketServer } from 'ws';
import { runAgent } from './agent/run.ts';
import type { ModelMessage } from 'ai';
import type { AgentCallbacks } from './types.ts';

const wss = new WebSocketServer({ port: 8080 });
console.log('WebSocket server running on ws://localhost:8080');

wss.on('connection', (ws) => {
  let conversationHistory: ModelMessage[] = [];

  ws.on('message', async (data) => {
    const userMessage = data.toString();

    const callbacks: AgentCallbacks = {
      onToken: (token) => {
        ws.send(JSON.stringify({ type: 'token', text: token }));
      },

      onToolCallStart: (name, args) => {
        ws.send(JSON.stringify({ type: 'tool_start', name, args }));
      },

      onToolCallEnd: (name, result) => {
        ws.send(JSON.stringify({ type: 'tool_end', name, result }));
      },

      onComplete: (response) => {
        ws.send(JSON.stringify({ type: 'complete', text: response }));
      },

      onToolApproval: async (name, args) => {
        // Send approval request to the browser
        ws.send(JSON.stringify({ type: 'approval_request', name, args }));

        // Wait for the browser to respond
        return new Promise((resolve) => {
          const handler = (msg: Buffer) => {
            const parsed = JSON.parse(msg.toString());
            if (parsed.type === 'approval_response') {
              ws.off('message', handler);
              resolve(parsed.approved);
            }
          };
          ws.on('message', handler);
        });
      },
    };

    conversationHistory = await runAgent(userMessage, conversationHistory, callbacks);
  });
});
```

## 3. The Callback Pattern Visualized

```
                    ┌─────────────────────┐
                    │    Agent Engine      │
                    │    (run.ts)          │
                    │                     │
                    │  callbacks.onToken() ──────┐
                    │  callbacks.onComplete()    │
                    │  callbacks.onToolApproval()│
                    └─────────────────────┘     │
                                                │
                    ┌───────────────────────────┘
                    │
         ┌──────────┼──────────┐
         │          │          │
    ┌────▼───┐ ┌────▼───┐ ┌───▼────┐
    │  TUI   │ │  Web   │ │ Discord│
    │  (Ink) │ │  (WS)  │ │  (Bot) │
    └────────┘ └────────┘ └────────┘
```

The engine is **one codebase**. The frontends are just different
implementations of `AgentCallbacks`.

## What You Just Built

```
src/
├── ui/
│   └── App.tsx              # Ink TUI (THIS lesson)
├── server.ts                # WebSocket server (THIS lesson)
├── index.tsx                # TUI entry point (THIS lesson)
├── agent/
│   ├── context/ ...
│   ├── run.ts
│   └── system/prompt.ts
├── TaskManager.ts
├── MessageRouter.ts
├── executeTool.ts
├── tools/ ...
└── types.ts
```

## Next: Lesson 07

We will add **Durable Execution** — writing every step to a JSONL file
on disk so the agent can survive crashes and resume exactly where it stopped.
