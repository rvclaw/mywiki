# Lesson 04: Background Tasks (Async OS Execution)

In Lesson 01, our `runCommand` tool uses `execSync` — it blocks the entire
Node.js thread until the command finishes. That's fine for `ls`, but
`npm install` takes 30 seconds. During that time, the agent can't do
anything else.

Production agents (Antigravity, Pi) solve this by:
1. Spawning the OS process asynchronously with `child_process.spawn`
2. Streaming stdout/stderr into a buffer
3. When the process exits, routing the result back through the `MessageRouter`
4. The agent sleeps the entire time — zero CPU

This lesson implements Pi's `bash-executor.ts` pattern.

## 1. The Task Manager (`src/TaskManager.ts`)

```typescript
// src/TaskManager.ts
import { spawn, type ChildProcess } from 'child_process';
import type { MessageRouter } from './MessageRouter.ts';

interface ActiveTask {
  process: ChildProcess;
  logs: string;
}

/**
 * Manages background OS processes.
 *
 * When a command is executed:
 * 1. spawn() asks the OS kernel to create a child process
 * 2. We attach listeners to stdout/stderr (non-blocking I/O via epoll/kqueue)
 * 3. We return immediately — the agent can go to sleep
 * 4. When the OS process exits, we route the output back to the agent
 *
 * Pattern: pi-main/packages/coding-agent/src/core/bash-executor.ts
 */
export class TaskManager {
  private activeTasks = new Map<string, ActiveTask>();

  constructor(private router: MessageRouter) {}

  /**
   * Spawn an OS command in the background.
   * Returns a task ID immediately. Does NOT block.
   */
  executeBackground(
    agentId: string,
    command: string,
    cwd: string = '.',
  ): string {
    const taskId = `task-${Date.now()}`;

    console.log(`[TaskManager] Spawning: ${command}`);

    // Ask the Operating System to create a child process.
    // On Linux/macOS, spawn uses posix_spawn or fork+exec.
    // On Windows, it uses CreateProcess.
    const child = spawn(command, {
      cwd,
      shell: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    const task: ActiveTask = { process: child, logs: '' };
    this.activeTasks.set(taskId, task);

    // --- Non-blocking I/O listeners ---
    // These callbacks fire when the OS kernel has data ready.
    // Between callbacks, Node's event loop is free (zero CPU).

    child.stdout?.on('data', (chunk: Buffer) => {
      const text = chunk.toString();
      task.logs += text;

      // Pi's bash-executor.ts does sanitization here:
      // - Strip ANSI escape codes (confuse the LLM)
      // - Replace binary garbage
      // - Truncate if output exceeds a threshold
    });

    child.stderr?.on('data', (chunk: Buffer) => {
      task.logs += chunk.toString();
    });

    // --- The Wake-Up Trigger ---
    // When the OS terminates the process, this fires.
    child.on('exit', (code) => {
      console.log(`[TaskManager] ${taskId} exited with code ${code}`);
      this.activeTasks.delete(taskId);

      // Truncate output for the LLM (like Pi does)
      const MAX_OUTPUT = 50_000; // ~50KB
      let output = task.logs;
      let truncated = false;
      if (output.length > MAX_OUTPUT) {
        output = output.slice(-MAX_OUTPUT);
        truncated = true;
      }

      const content = [
        `Command finished with exit code ${code}.`,
        truncated ? `(Output truncated to last ${MAX_OUTPUT} chars)` : '',
        `\nOutput:\n${output}`,
      ].join('\n');

      // Route the result back to the agent that spawned this task
      this.router.routeMessage({
        senderId: taskId,
        recipientId: agentId,
        content,
        priority: 'HIGH',
        timestamp: Date.now(),
      });
    });

    return taskId;
  }

  /**
   * Kill a running task.
   */
  kill(taskId: string): boolean {
    const task = this.activeTasks.get(taskId);
    if (!task) return false;
    task.process.kill('SIGTERM');
    this.activeTasks.delete(taskId);
    return true;
  }
}
```

## 2. Upgrading the Shell Tool

Now we replace the synchronous `execSync` with an async version that uses
the `TaskManager`:

```typescript
// src/tools/shell.ts (updated)
import { tool } from 'ai';
import { z } from 'zod';
import { execSync } from 'child_process';

/**
 * For the agent loop (lesson 02), we still use execSync because
 * the Vercel AI SDK tool.execute() is expected to return a result.
 *
 * But for multi-agent scenarios (lesson 03), the orchestrator can
 * use TaskManager.executeBackground() directly to run long commands
 * without blocking.
 *
 * Production systems like Pi use BOTH patterns:
 * - Short commands (ls, cat): synchronous
 * - Long commands (npm install, build): background task
 */
export const runCommand = tool({
  description: 'Execute a shell command and return its output.',
  inputSchema: z.object({
    command: z.string().describe('The shell command to execute'),
  }),
  execute: async ({ command }) => {
    try {
      const output = execSync(command, {
        encoding: 'utf-8',
        timeout: 30_000,
        maxBuffer: 1024 * 1024,
      });
      return output || 'Command completed successfully (no output)';
    } catch (error: any) {
      return `Command failed (exit code ${error.status}):\n${error.stderr || error.stdout || error.message}`;
    }
  },
});
```

## 3. How the OS Handles This (The Kernel Layer)

When `spawn()` runs, here's what happens at the OS level:

```
Your Node.js Process          OS Kernel              npm Process
       |                         |                       |
       |--- spawn("npm i") ----->|                       |
       |                         |--- fork/exec -------->|
       |                         |                       |
       |  (Node thread is free)  |   (downloading...)    |
       |  (CPU usage = 0%)       |                       |
       |                         |                       |
       |                         |<-- stdout data -------|
       |<-- 'data' event --------|                       |
       |  (append to buffer)     |                       |
       |                         |                       |
       |                         |<-- process exits -----|
       |<-- 'exit' event --------|                       |
       |  (route to agent)       |                       |
```

Node.js uses **libuv** which calls **epoll** (Linux) or **kqueue** (macOS).
These are OS kernel APIs that say: *"Wake me up when this file descriptor
has data."* The thread literally sleeps at the hardware level.

## What You Just Built

```
src/
├── TaskManager.ts           # Background OS execution (THIS lesson)
├── MessageRouter.ts         # Message routing (lesson 03)
├── agent/
│   ├── run.ts
│   └── system/prompt.ts
├── executeTool.ts
├── tools/
│   ├── index.ts
│   ├── file.ts
│   └── shell.ts
└── types.ts
```

## Next: Lesson 05

We will add **Context Management** — token estimation and LLM-based
conversation compaction so the agent doesn't blow its context window
during long conversations.
