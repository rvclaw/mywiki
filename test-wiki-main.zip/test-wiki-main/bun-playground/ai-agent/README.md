# Build an AI Agent Engine from Scratch

A step-by-step guide to building a production-grade agentic runtime in TypeScript.
Inspired by real-world architectures from **Pi**, **OpenCode**, and **Antigravity**.

## Philosophy

> Not "build an agent." Build the thing that can durably run any of them.

We are building a **Harness** — the engine that manages the agent's lifecycle,
routes messages, executes tools, manages context windows, connects to frontends,
and survives crashes.

## Prerequisites

- Comfortable with TypeScript and Node.js
- Can run `bun` or `node` locally
- An API key for at least one LLM provider (OpenAI, Anthropic, Google, etc.)

## Lessons

Each lesson builds on the previous one. The code is cumulative.

| # | Lesson | What You Build | Key Concept |
|---|--------|---------------|-------------|
| 01 | [Types & Tool Registry](./01-types-and-tools.md) | Core types, Zod schemas, tool definitions | Tool-calling contract |
| 02 | [The Agent Loop](./02-agent-loop.md) | The `while(true)` streaming loop | `streamText` + `finishReason` |
| 03 | [The Message Router](./03-message-router.md) | Point-to-point mailbox for agents | Promise suspension |
| 04 | [Background Tasks](./04-background-tasks.md) | OS process execution via `child_process` | Non-blocking I/O |
| 05 | [Context Management](./05-context-management.md) | Token estimation + LLM-based compaction | Staying under token limits |
| 06 | [Frontend Integration](./06-frontend-integration.md) | TUI with Ink + WebSocket server | Headless engine pattern |
| 07 | [Durable Execution](./07-durable-execution.md) | JSONL transcript + crash recovery | Append-only event log |
| 08 | [Subagents & Orchestration](./08-subagents.md) | SubagentManager, invoke_subagent tool | Actor model, session branching |
| 09 | [The Event Bus](./09-event-bus.md) | Pub/sub broadcast for engine observability | Pi's event-bus.ts pattern |

## Tech Stack

| Layer | Choice | Why |
|-------|--------|-----|
| Runtime | Bun or Node.js | Fast, TypeScript-native |
| LLM SDK | Vercel AI SDK (`ai`) | Provider-agnostic, streaming, tool calling built-in |
| Schema | Zod | Runtime validation + type inference |
| TUI | Ink (React for CLI) | Same React mental model for terminal UI |
| Process | `child_process.spawn` | Non-blocking OS command execution |

## How to Start

```bash
cd C:\Users\dawar\projects\test\bun-playground\ai-agent
bun init
bun add ai @ai-sdk/openai zod
bun add -d @types/node
mkdir src
```

Then open `01-types-and-tools.md` and start coding.
