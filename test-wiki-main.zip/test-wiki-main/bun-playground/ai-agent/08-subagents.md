# Lesson 08: Subagents & Orchestration

This is where it all comes together. In Antigravity, when the orchestrator
calls `invoke_subagent`, the engine:

1. Creates a **new Agent instance** with its own conversation ID
2. Starts its event loop in the background (no `await` — fire and forget)
3. Sends the initial prompt to the subagent's inbox via the `MessageRouter`
4. The orchestrator **goes to sleep** (back to `waitForMessages`)
5. The subagent runs independently — calling tools, thinking, streaming
6. When the subagent finishes, it calls `send_message` back to the orchestrator
7. The router resolves the orchestrator's suspended Promise → it wakes up

In Pi, this is called **Session Branching** — forking a new session from a
parent session (`parentSession` in `session-manager.ts`).

## 1. The Subagent Manager (`src/SubagentManager.ts`)

```typescript
// src/SubagentManager.ts
import { MessageRouter } from './MessageRouter.ts';
import { TaskManager } from './TaskManager.ts';
import { runAgent } from './agent/run.ts';
import type { ModelMessage } from 'ai';
import type { AgentCallbacks } from './types.ts';

interface SubagentInfo {
  conversationId: string;
  role: string;
  state: 'running' | 'idle' | 'killed';
  parentId: string;
}

/**
 * Manages the lifecycle of subagents.
 *
 * In Antigravity:
 * - Each subagent gets a unique conversationId
 * - Subagents run their own agent loop independently
 * - They communicate with the parent ONLY through the MessageRouter
 * - The parent never calls subagent methods directly (Actor Model)
 *
 * In Pi:
 * - Subagents are "branched sessions" (session-manager.ts line 849)
 * - Each branch gets its own JSONL session file
 * - The parent stores a `parentSession` reference
 */
export class SubagentManager {
  private subagents = new Map<string, SubagentInfo>();

  constructor(
    private router: MessageRouter,
    private taskManager: TaskManager,
  ) {}

  /**
   * Spawn a new subagent. Returns its conversationId immediately.
   * The subagent starts running in the background.
   */
  async spawn(
    parentId: string,
    role: string,
    prompt: string,
    systemPrompt?: string,
  ): Promise<string> {
    const conversationId = `subagent-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    // Register the subagent's inbox with the router
    this.router.registerAgent(conversationId);

    const info: SubagentInfo = {
      conversationId,
      role,
      state: 'running',
      parentId,
    };
    this.subagents.set(conversationId, info);

    // Start the subagent's event loop in the background
    // IMPORTANT: We do NOT await this. It runs independently.
    this.runSubagentLoop(conversationId, parentId, prompt, systemPrompt);

    return conversationId;
  }

  /**
   * The subagent's independent event loop.
   * It runs the agent, and when done, sends the result back to the parent.
   */
  private async runSubagentLoop(
    conversationId: string,
    parentId: string,
    prompt: string,
    systemPrompt?: string,
  ) {
    const info = this.subagents.get(conversationId)!;
    let fullResponse = '';

    // Create callbacks that accumulate the subagent's response
    const callbacks: AgentCallbacks = {
      onToken: (token) => {
        fullResponse += token;
      },
      onToolCallStart: (name) => {
        console.log(`  [${info.role}] Using tool: ${name}`);
      },
      onToolCallEnd: () => {},
      onComplete: (response) => {
        fullResponse = response;
      },
      onToolApproval: async () => true, // Subagents auto-approve tools
    };

    try {
      // Run the standard agent loop (from lesson 02)
      await runAgent(
        prompt,
        [], // Fresh conversation history
        callbacks,
      );

      info.state = 'idle';

      // Send the result back to the parent agent via the router
      this.router.routeMessage({
        senderId: conversationId,
        recipientId: parentId,
        content: `[Subagent "${info.role}" completed]:\n${fullResponse}`,
        priority: 'HIGH',
        timestamp: Date.now(),
      });

    } catch (error) {
      info.state = 'idle';
      this.router.routeMessage({
        senderId: conversationId,
        recipientId: parentId,
        content: `[Subagent "${info.role}" FAILED]: ${error}`,
        priority: 'HIGH',
        timestamp: Date.now(),
      });
    }
  }

  /**
   * Send a message to an existing subagent (wake it up with new work).
   */
  sendMessage(recipientId: string, senderId: string, content: string): void {
    this.router.routeMessage({
      senderId,
      recipientId,
      content,
      priority: 'HIGH',
      timestamp: Date.now(),
    });
  }

  /**
   * Kill a subagent and all its descendants.
   */
  kill(conversationId: string): boolean {
    const info = this.subagents.get(conversationId);
    if (!info) return false;
    info.state = 'killed';
    this.subagents.delete(conversationId);
    return true;
  }

  /**
   * List all active subagents.
   */
  list(): SubagentInfo[] {
    return Array.from(this.subagents.values());
  }
}
```

## 2. The `invoke_subagent` Tool

This is the tool the LLM calls when it decides to delegate work.

```typescript
// src/tools/subagent.ts
import { tool } from 'ai';
import { z } from 'zod';
import type { SubagentManager } from '../SubagentManager.ts';

/**
 * Create the invoke_subagent tool.
 * We need to pass in the SubagentManager instance at runtime.
 */
export function createSubagentTools(
  parentId: string,
  subagentManager: SubagentManager,
) {
  const invokeSubagent = tool({
    description: 'Spawn a subagent to handle a specific task in the background. The subagent will message you when done.',
    inputSchema: z.object({
      role: z.string().describe('A short role name like "Backend Developer" or "Test Writer"'),
      prompt: z.string().describe('Detailed instructions for the subagent'),
    }),
    execute: async ({ role, prompt }) => {
      const subagentId = await subagentManager.spawn(
        parentId,
        role,
        prompt,
      );
      return `Subagent "${role}" spawned with ID: ${subagentId}. It is running in the background. You will receive a message when it finishes.`;
    },
  });

  const sendMessage = tool({
    description: 'Send a message to a running subagent.',
    inputSchema: z.object({
      recipientId: z.string().describe('The conversation ID of the subagent'),
      message: z.string().describe('The message to send'),
    }),
    execute: async ({ recipientId, message }) => {
      subagentManager.sendMessage(recipientId, parentId, message);
      return `Message sent to ${recipientId}.`;
    },
  });

  const listSubagents = tool({
    description: 'List all active subagents and their status.',
    inputSchema: z.object({}),
    execute: async () => {
      const agents = subagentManager.list();
      if (agents.length === 0) return 'No active subagents.';
      return agents
        .map((a) => `- ${a.role} (${a.conversationId}): ${a.state}`)
        .join('\n');
    },
  });

  return { invokeSubagent, sendMessage, listSubagents };
}
```

## 3. The Orchestrator (Combining Everything)

Now we wire the orchestrator to use both regular tools AND subagent tools,
and integrate with the `MessageRouter` for the sleep/wake cycle.

```typescript
// src/orchestrator.ts
import { MessageRouter } from './MessageRouter.ts';
import { TaskManager } from './TaskManager.ts';
import { SubagentManager } from './SubagentManager.ts';
import { runAgent } from './agent/run.ts';
import { createSubagentTools } from './tools/subagent.ts';
import type { ModelMessage } from 'ai';
import type { AgentCallbacks } from './types.ts';

const ORCHESTRATOR_ID = 'orchestrator-main';

export async function startOrchestrator(callbacks: AgentCallbacks) {
  const router = new MessageRouter();
  const taskManager = new TaskManager(router);
  const subagentManager = new SubagentManager(router, taskManager);

  router.registerAgent(ORCHESTRATOR_ID);

  let conversationHistory: ModelMessage[] = [];

  // The orchestrator's main loop
  while (true) {
    // 1. SLEEP until something happens
    //    (user message, subagent reply, or task completion)
    const incomingMessages = await router.waitForMessages(ORCHESTRATOR_ID);

    // 2. Inject all incoming messages into the conversation
    for (const msg of incomingMessages) {
      conversationHistory.push({
        role: 'user',
        content: `<SYSTEM_MESSAGE>\n[Message from ${msg.senderId}]:\n${msg.content}\n</SYSTEM_MESSAGE>`,
      });
    }

    // 3. Run the agent loop (which may spawn subagents)
    conversationHistory = await runAgent(
      '', // No new user message — we already injected the incoming messages
      conversationHistory,
      callbacks,
    );
  }
}
```

## 4. How the Full Flow Works

```
┌──────────────┐     routeMessage()      ┌──────────────┐
│              │ ◄──────────────────────  │              │
│ Orchestrator │                          │  Subagent A  │
│  (sleeping)  │  ──────────────────────► │  (running)   │
│              │     invoke_subagent()    │              │
└──────────────┘                          └──────────────┘
       │                                         │
       │  waitForMessages()                      │  runAgent()
       │  ── Promise suspends ──                 │  ── calling tools ──
       │                                         │
       │  ← resolved when                        │  → sends result
       │    subagent finishes                     │    via router
```

1. User says: *"Set up the database and write tests"*
2. Orchestrator calls `invoke_subagent({ role: "DB Agent", prompt: "Set up Drizzle..." })`
3. Orchestrator calls `invoke_subagent({ role: "Test Writer", prompt: "Write vitest tests..." })`
4. Both subagents start running **concurrently**
5. Orchestrator goes to sleep (`waitForMessages`)
6. DB Agent finishes first → routes message to orchestrator
7. Orchestrator wakes up, sees one result, goes back to sleep
8. Test Writer finishes → routes message to orchestrator
9. Orchestrator wakes up, sees both results, responds to user

**This is exactly how the conversation you and I are having works.
Right now, I am the orchestrator, and when I spawned the "Backend Setup Agent"
earlier, it ran independently and messaged me when it was done.**

## What You Just Built

```
src/
├── SubagentManager.ts       # Subagent lifecycle (THIS lesson)
├── orchestrator.ts          # Multi-agent orchestration (THIS lesson)
├── tools/
│   ├── subagent.ts          # invoke_subagent tool (THIS lesson)
│   ├── index.ts
│   ├── file.ts
│   └── shell.ts
├── agent/
│   ├── context/ ...
│   ├── run.ts
│   └── system/prompt.ts
├── TranscriptLogger.ts
├── TaskManager.ts
├── MessageRouter.ts
├── executeTool.ts
└── types.ts
```

## Next: Lesson 09

We will build the **Event Bus** — a pub/sub system that broadcasts every
engine event (tool starts, token streams, state changes) to all
subscribers. This is what lets the TUI render tool progress bars while
the agent is thinking.
