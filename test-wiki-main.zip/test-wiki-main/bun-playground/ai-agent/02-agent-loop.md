# Lesson 02: The Agent Loop

This is the core of the entire system. The agent loop is a `while(true)` that:
1. Sends the conversation history to the LLM via `streamText()`
2. Streams tokens back to the UI via callbacks
3. Collects tool calls from the LLM's response
4. Checks the `finishReason` — if it's `"tool-calls"`, execute them and loop again
5. If the LLM stops naturally (no more tool calls), break out of the loop

This pattern comes directly from the **agents-v2 course** (`run.ts`).

## 1. The Agent Runner (`src/agent/run.ts`)

```typescript
// src/agent/run.ts
import { streamText, type ModelMessage } from 'ai';
import { openai } from '@ai-sdk/openai';
import { tools } from '../tools/index.ts';
import { executeTool } from '../executeTool.ts';
import { SYSTEM_PROMPT } from './system/prompt.ts';
import type { AgentCallbacks, ToolCallInfo } from '../types.ts';

/**
 * Run the agent loop for one user turn.
 *
 * Takes the user's message and the full conversation history,
 * loops until the LLM stops calling tools, and returns the
 * updated conversation history.
 *
 * Pattern: agents-v2/src/agent/run.ts
 */
export async function runAgent(
  userMessage: string,
  conversationHistory: ModelMessage[],
  callbacks: AgentCallbacks,
): Promise<ModelMessage[]> {

  // Build the full message array
  const messages: ModelMessage[] = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...conversationHistory,
    { role: 'user', content: userMessage },
  ];

  let fullResponse = '';

  // THE AGENT LOOP
  while (true) {

    // 1. Stream the LLM response
    const result = streamText({
      model: openai('gpt-4o'),
      messages,
      tools,
    });

    const toolCalls: ToolCallInfo[] = [];
    let currentText = '';

    // 2. Process the stream chunk by chunk
    for await (const chunk of result.fullStream) {

      // Text token — stream it to the UI
      if (chunk.type === 'text-delta') {
        currentText += chunk.text;
        callbacks.onToken(chunk.text);
      }

      // Tool call — collect it
      if (chunk.type === 'tool-call') {
        const input = 'input' in chunk ? chunk.input : {};
        toolCalls.push({
          toolCallId: chunk.toolCallId,
          toolName: chunk.toolName,
          args: input as Record<string, unknown>,
        });
        callbacks.onToolCallStart(chunk.toolName, input);
      }
    }

    fullResponse += currentText;

    // 3. Check the finish reason
    const finishReason = await result.finishReason;

    // If the LLM did NOT request tool calls, we're done
    if (finishReason !== 'tool-calls' || toolCalls.length === 0) {
      const responseMessages = await result.response;
      messages.push(...responseMessages.messages);
      break;
    }

    // 4. The LLM requested tool calls — execute them
    const responseMessages = await result.response;
    messages.push(...responseMessages.messages);

    // Process each tool call sequentially with HITL approval
    let rejected = false;
    for (const tc of toolCalls) {

      // Ask the UI for approval (Human-in-the-Loop)
      const approved = await callbacks.onToolApproval(tc.toolName, tc.args);

      if (!approved) {
        rejected = true;
        break;
      }

      // Execute the tool
      const toolResult = await executeTool(tc.toolName, tc.args);
      callbacks.onToolCallEnd(tc.toolName, toolResult);

      // Push the tool result back into the conversation
      messages.push({
        role: 'tool',
        content: [{
          type: 'tool-result',
          toolCallId: tc.toolCallId,
          toolName: tc.toolName,
          output: { type: 'text', value: toolResult },
        }],
      });
    }

    if (rejected) break;

    // 5. Loop again — the LLM will see the tool results and decide
    //    whether to call more tools or respond to the user
  }

  callbacks.onComplete(fullResponse);
  return messages;
}
```

## 2. The System Prompt (`src/agent/system/prompt.ts`)

```typescript
// src/agent/system/prompt.ts

export const SYSTEM_PROMPT = `You are a helpful coding agent.
You have access to file system tools and a shell.
Use tools to help the user accomplish tasks.

Rules:
- Always read files before modifying them.
- Explain what you are doing before using tools.
- If a command might be destructive, warn the user.
`;
```

---

## How It Works (Step by Step)

1. User types: *"Create a file called hello.ts"*
2. The agent loop calls `streamText()` with the full conversation.
3. The LLM streams back: *"I'll create that file for you."*
   — Each token fires `callbacks.onToken("I'll")`, `callbacks.onToken(" create")`, etc.
4. The LLM also emits a `tool-call` chunk: `writeFile({ path: "hello.ts", content: "..." })`.
5. `finishReason` is `"tool-calls"`.
6. We call `callbacks.onToolApproval("writeFile", ...)` — the UI shows a prompt.
7. User approves → we call `executeTool("writeFile", ...)`.
8. The tool result is pushed into `messages`.
9. We **loop back** to step 2. The LLM sees the tool result and says: *"Done! File created."*
10. `finishReason` is `"stop"` → we break out of the loop.

This is the **exact same loop** that powers Claude Code, Cursor, and Pi.

## What You Just Built

```
src/
├── agent/
│   ├── run.ts              # The agent loop (THIS lesson)
│   └── system/
│       └── prompt.ts       # System prompt
├── executeTool.ts          # Tool dispatcher (lesson 01)
├── tools/                  # Tool definitions (lesson 01)
│   ├── index.ts
│   ├── file.ts
│   └── shell.ts
└── types.ts                # Core types (lesson 01)
```

## Next: Lesson 03

We will build the **Message Router** — the event bus that lets multiple agents
and background tasks communicate without knowing about each other.
