# Lesson 07: Durable Execution

If your agent is halfway through a complex task and the process crashes —
power outage, OOM kill, server restart — all progress is lost. The agent
starts from scratch.

**Durable Execution** solves this by writing every step to an **append-only
event log** on disk. When the agent reboots, it reads the log and rebuilds
its memory to the exact state before the crash.

This is the pattern used by:
- **Antigravity**: `transcript.jsonl` files under `.system_generated/logs/`
- **Pi**: `session-manager.ts` persists session state to SQLite
- **Temporal.io / Durable Objects**: The same concept at infrastructure scale

## 1. The Transcript Logger (`src/TranscriptLogger.ts`)

We use the **JSONL format** (JSON Lines) — one JSON object per line.
This format is ideal because:
- **Append-only**: We never rewrite the file, just append
- **Streaming**: We can read line-by-line without loading the entire file
- **Crash-safe**: A partial last line is easy to detect and skip

```typescript
// src/TranscriptLogger.ts
import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';
import type { ModelMessage } from 'ai';

/**
 * Writes and reads agent memory to/from a .jsonl file.
 *
 * Each line is one message in the agent's conversation history.
 * On boot, we read the file to "hydrate" the agent's memory.
 * During execution, every new message is appended immediately.
 *
 * Pattern: Antigravity's transcript.jsonl
 */
export class TranscriptLogger {
  private filePath: string;

  constructor(conversationId: string, logsDir: string = './logs') {
    // Ensure the logs directory exists
    fs.mkdirSync(logsDir, { recursive: true });
    this.filePath = path.join(logsDir, `${conversationId}.jsonl`);
  }

  /**
   * Append a message to the log.
   * Uses appendFileSync for crash safety — the write hits disk before
   * we continue execution.
   */
  append(message: ModelMessage): void {
    const line = JSON.stringify({
      timestamp: new Date().toISOString(),
      ...message,
    }) + '\n';

    fs.appendFileSync(this.filePath, line, 'utf-8');
  }

  /**
   * Read the entire log to rebuild the agent's memory.
   * Called "Context Hydration" — rehydrating the context from disk.
   *
   * Uses createReadStream + readline for memory efficiency.
   * Even a 100MB log file won't OOM your process.
   */
  async hydrate(): Promise<ModelMessage[]> {
    if (!fs.existsSync(this.filePath)) return [];

    const messages: ModelMessage[] = [];
    const stream = fs.createReadStream(this.filePath);
    const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });

    for await (const line of rl) {
      if (!line.trim()) continue;

      try {
        const { timestamp, ...message } = JSON.parse(line);
        messages.push(message as ModelMessage);
      } catch {
        // Skip corrupted lines (e.g., from a mid-write crash)
        console.warn(`[TranscriptLogger] Skipping corrupted line: ${line.slice(0, 50)}...`);
      }
    }

    return messages;
  }

  /**
   * Get the path to the log file (useful for debugging).
   */
  getPath(): string {
    return this.filePath;
  }
}
```

## 2. Integrating Durability into the Agent Loop

We update `run.ts` to log every message as it happens:

```typescript
// In run.ts — add logging at each critical point

import { TranscriptLogger } from '../TranscriptLogger.ts';

const logger = new TranscriptLogger('session-001');

export async function runAgent(
  userMessage: string,
  conversationHistory: ModelMessage[],
  callbacks: AgentCallbacks,
): Promise<ModelMessage[]> {

  const messages: ModelMessage[] = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...conversationHistory,
    { role: 'user', content: userMessage },
  ];

  // LOG: User's message
  logger.append({ role: 'user', content: userMessage });

  while (true) {
    const result = streamText({ model: openai('gpt-4o'), messages, tools });

    // ... stream processing ...

    const responseMessages = await result.response;
    messages.push(...responseMessages.messages);

    // LOG: Assistant's response (including tool calls)
    for (const msg of responseMessages.messages) {
      logger.append(msg);
    }

    if (finishReason !== 'tool-calls') break;

    // ... execute tools ...

    // LOG: Tool results
    for (const toolResult of toolResults) {
      logger.append(toolResult);
    }
  }

  return messages;
}
```

## 3. Crash Recovery (Hydration on Boot)

When the agent starts up, check if a previous session exists:

```typescript
// src/boot.ts
import { TranscriptLogger } from './TranscriptLogger.ts';

async function boot() {
  const logger = new TranscriptLogger('session-001');

  // Hydrate: Read the previous session from disk
  const previousMessages = await logger.hydrate();

  if (previousMessages.length > 0) {
    console.log(`[Boot] Recovered ${previousMessages.length} messages from disk`);
    console.log(`[Boot] Resuming session from: ${logger.getPath()}`);
    // Pass previousMessages as conversationHistory to runAgent()
  } else {
    console.log('[Boot] Starting fresh session');
  }
}
```

## 4. What the JSONL File Looks Like

After a conversation, `logs/session-001.jsonl` contains:

```jsonl
{"timestamp":"2026-08-10T01:00:00Z","role":"user","content":"Create a hello.ts file"}
{"timestamp":"2026-08-10T01:00:01Z","role":"assistant","content":"I'll create that file for you.","tool_calls":[{"id":"call_1","function":{"name":"writeFile","arguments":"{\"path\":\"hello.ts\",\"content\":\"console.log('hello')\"}"}}]}
{"timestamp":"2026-08-10T01:00:02Z","role":"tool","content":[{"type":"tool-result","toolCallId":"call_1","toolName":"writeFile","output":{"type":"text","value":"Successfully wrote 22 characters to hello.ts"}}]}
{"timestamp":"2026-08-10T01:00:03Z","role":"assistant","content":"Done! I created hello.ts with a simple console.log statement."}
```

If the process crashes after line 2, rebooting will hydrate lines 1-2.
The agent sees: *"I was in the middle of creating a file"* — and can
resume or retry.

## Final Architecture

```
src/
├── TranscriptLogger.ts      # JSONL read/write (THIS lesson)
├── boot.ts                  # Crash recovery entry point (THIS lesson)
├── ui/
│   └── App.tsx
├── server.ts
├── index.tsx
├── agent/
│   ├── context/
│   │   ├── index.ts
│   │   ├── tokenEstimator.ts
│   │   ├── modelLimits.ts
│   │   └── compaction.ts
│   ├── run.ts
│   └── system/prompt.ts
├── TaskManager.ts
├── MessageRouter.ts
├── executeTool.ts
├── tools/
│   ├── index.ts
│   ├── file.ts
│   └── shell.ts
└── types.ts
```

## Congratulations! 🎉

You have built a complete, production-grade agent engine from scratch:

| Lesson | What | Pattern Source |
|--------|------|---------------|
| 01 | Types & Tools | agents-v2 `types.ts`, `tools/` |
| 02 | Agent Loop | agents-v2 `run.ts` |
| 03 | Message Router | Antigravity, Pi `event-bus.ts` |
| 04 | Background Tasks | Pi `bash-executor.ts` |
| 05 | Context Management | agents-v2 `context/` |
| 06 | Frontend Integration | agents-v2 `App.tsx`, Antigravity |
| 07 | Durable Execution | Antigravity `transcript.jsonl` |

You now understand the exact primitives that power **Cursor, Claude Code,
Antigravity, Pi, and OpenCode**. Every single one is a variation on these
7 building blocks.
