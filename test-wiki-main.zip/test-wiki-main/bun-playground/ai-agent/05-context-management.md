# Lesson 05: Context Management

LLMs have a finite context window (e.g., GPT-4o = 128K tokens).
Long conversations — especially ones with large tool outputs like file
contents or npm logs — will blow past this limit and crash.

The agents-v2 course solves this with two techniques:
1. **Token Estimation**: Cheaply estimate how many tokens the conversation uses
2. **Compaction**: When you're over a threshold, use the LLM itself to
   summarize the conversation into a compact form

This is the same pattern used by Pi's `compaction/` module and
Antigravity's `CHECKPOINT` system.

## 1. Token Estimator (`src/agent/context/tokenEstimator.ts`)

```typescript
// src/agent/context/tokenEstimator.ts
import type { ModelMessage } from 'ai';

/**
 * Rough token estimation.
 * The standard rule of thumb: 1 token ≈ 4 characters for English text.
 * This avoids importing a full tokenizer (like tiktoken) for estimation.
 *
 * Pattern: agents-v2/src/agent/context/tokenEstimator.ts
 */

const CHARS_PER_TOKEN = 4;

export function extractMessageText(message: ModelMessage): string {
  if (typeof message.content === 'string') return message.content;
  if (Array.isArray(message.content)) {
    return message.content
      .map((part) => {
        if (typeof part === 'string') return part;
        if ('text' in part) return part.text;
        if ('output' in part && typeof part.output === 'object' && part.output && 'value' in part.output) {
          return String(part.output.value);
        }
        return JSON.stringify(part);
      })
      .join(' ');
  }
  return '';
}

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / CHARS_PER_TOKEN);
}

export function estimateMessagesTokens(messages: ModelMessage[]) {
  let input = 0;
  let output = 0;

  for (const msg of messages) {
    const tokens = estimateTokens(extractMessageText(msg));
    if (msg.role === 'assistant') {
      output += tokens;
    } else {
      input += tokens;
    }
  }

  return { input, output, total: input + output };
}
```

## 2. Model Limits (`src/agent/context/modelLimits.ts`)

```typescript
// src/agent/context/modelLimits.ts
import type { ModelLimits } from '../../types.ts';

/**
 * Known context windows for popular models.
 * Pattern: agents-v2/src/agent/context/modelLimits.ts
 */
const MODEL_LIMITS: Record<string, ModelLimits> = {
  'gpt-4o':       { contextWindow: 128_000, inputLimit: 128_000, outputLimit: 16_384 },
  'gpt-4o-mini':  { contextWindow: 128_000, inputLimit: 128_000, outputLimit: 16_384 },
  'gpt-5-mini':   { contextWindow: 1_000_000, inputLimit: 1_000_000, outputLimit: 100_000 },
  'claude-sonnet-4-20250514': { contextWindow: 200_000, inputLimit: 200_000, outputLimit: 64_000 },
};

const DEFAULT_LIMITS: ModelLimits = {
  contextWindow: 128_000,
  inputLimit: 128_000,
  outputLimit: 16_384,
};

export function getModelLimits(model: string): ModelLimits {
  return MODEL_LIMITS[model] ?? DEFAULT_LIMITS;
}
```

## 3. Conversation Compaction (`src/agent/context/compaction.ts`)

When the conversation is too long, we ask the LLM to summarize it.
The summary replaces the entire history, dramatically reducing tokens.

```typescript
// src/agent/context/compaction.ts
import { generateText, type ModelMessage } from 'ai';
import { openai } from '@ai-sdk/openai';
import { extractMessageText } from './tokenEstimator.ts';

/**
 * The summarization prompt.
 * Pattern: agents-v2/src/agent/context/compaction.ts
 */
const SUMMARIZATION_PROMPT = `You are a conversation summarizer. Create a concise summary that preserves:

1. Key decisions and conclusions reached
2. Important context and facts mentioned
3. Any pending tasks or questions
4. The overall goal of the conversation

Be concise but complete. The summary should allow the conversation to continue naturally.

Conversation to summarize:
`;

function messagesToText(messages: ModelMessage[]): string {
  return messages
    .map((msg) => {
      const role = msg.role.toUpperCase();
      const content = extractMessageText(msg);
      return `[${role}]: ${content}`;
    })
    .join('\n\n');
}

/**
 * Compact a conversation by summarizing it with an LLM.
 *
 * Returns a new, much shorter message array that preserves
 * the essential context.
 */
export async function compactConversation(
  messages: ModelMessage[],
  model: string = 'gpt-4o-mini',
): Promise<ModelMessage[]> {
  // Skip system messages — the caller handles those
  const conversationMessages = messages.filter((m) => m.role !== 'system');
  if (conversationMessages.length === 0) return [];

  const conversationText = messagesToText(conversationMessages);

  const { text: summary } = await generateText({
    model: openai(model),
    prompt: SUMMARIZATION_PROMPT + conversationText,
  });

  // Replace the entire history with a compact summary
  return [
    {
      role: 'user',
      content: `[CONVERSATION SUMMARY]\n${summary}\n\nPlease continue from where we left off.`,
    },
    {
      role: 'assistant',
      content: "Understood. I've reviewed our conversation summary and I'm ready to continue.",
    },
  ];
}
```

## 4. Threshold Helpers (`src/agent/context/index.ts`)

```typescript
// src/agent/context/index.ts
export { estimateMessagesTokens, estimateTokens } from './tokenEstimator.ts';
export { getModelLimits } from './modelLimits.ts';
export { compactConversation } from './compaction.ts';

/** Compact when we hit 70% of the context window */
export const DEFAULT_THRESHOLD = 0.7;

export function isOverThreshold(tokens: number, contextWindow: number): boolean {
  return tokens > contextWindow * DEFAULT_THRESHOLD;
}

export function calculateUsagePercentage(tokens: number, contextWindow: number): number {
  return Math.round((tokens / contextWindow) * 100);
}
```

## 5. Integrating into the Agent Loop

Update `run.ts` to check the context before each LLM call:

```typescript
// In run.ts, before the while(true) loop:
import { estimateMessagesTokens, getModelLimits, isOverThreshold, compactConversation } from './context/index.ts';

const modelLimits = getModelLimits('gpt-4o');

// Check if we need to compact BEFORE starting
const preCheck = estimateMessagesTokens(messages);
if (isOverThreshold(preCheck.total, modelLimits.contextWindow)) {
  const compacted = await compactConversation(conversationHistory, 'gpt-4o-mini');
  // Replace history with compacted version
  messages.length = 0;
  messages.push({ role: 'system', content: SYSTEM_PROMPT }, ...compacted, { role: 'user', content: userMessage });
}
```

## What You Just Built

```
src/
├── agent/
│   ├── context/
│   │   ├── index.ts            # Barrel exports + threshold helpers (THIS)
│   │   ├── tokenEstimator.ts   # Cheap token counting (THIS)
│   │   ├── modelLimits.ts      # Known model context windows (THIS)
│   │   └── compaction.ts       # LLM-based summarization (THIS)
│   ├── run.ts
│   └── system/prompt.ts
├── TaskManager.ts
├── MessageRouter.ts
├── executeTool.ts
├── tools/ ...
└── types.ts
```

## Next: Lesson 06

We will connect the engine to a **real frontend** — building a TUI with
Ink (React for the terminal) and a WebSocket server for web apps.
