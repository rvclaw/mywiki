# Lesson 01: Types & Tool Registry

Before writing any agent logic, we define the **contract** — the types that
every piece of the system agrees on. This is what makes the architecture
extensible. New tools, new frontends, new LLM providers — they all plug
into these shared types.

## 1. Core Types (`src/types.ts`)

The agents-v2 course uses a beautiful pattern: **Callbacks**. The agent
engine doesn't know anything about the UI. Instead, it accepts a bag of
callback functions. The UI provides the implementations.

This is the exact same pattern Pi uses in its `AgentSession`.

```typescript
// src/types.ts

/**
 * A message flowing through the router between agents or tasks.
 */
export interface Message {
  senderId: string;
  recipientId: string;
  content: string;
  priority: 'HIGH' | 'LOW';
  timestamp: number;
}

/**
 * Lifecycle state of an Agent.
 */
export type AgentState =
  | 'IDLE'
  | 'RUNNING'
  | 'WAITING_FOR_MESSAGES'
  | 'KILLED';

/**
 * Callbacks the UI provides to the engine.
 * This is how the engine talks to ANY frontend (TUI, Web, Discord bot)
 * without knowing what the frontend is.
 *
 * Pattern source: agents-v2/src/types.ts
 */
export interface AgentCallbacks {
  /** Called for each streaming token from the LLM */
  onToken: (token: string) => void;

  /** Called when the agent starts executing a tool */
  onToolCallStart: (name: string, args: unknown) => void;

  /** Called when a tool finishes with its result */
  onToolCallEnd: (name: string, result: string) => void;

  /** Called when the agent's full response is complete */
  onComplete: (response: string) => void;

  /** Called when a dangerous tool needs human approval.
   *  The UI must return true/false via the Promise.
   *  This is the Human-in-the-Loop (HITL) pattern. */
  onToolApproval: (name: string, args: unknown) => Promise<boolean>;
}

/**
 * Info about a tool call in progress.
 */
export interface ToolCallInfo {
  toolCallId: string;
  toolName: string;
  args: Record<string, unknown>;
}
```

---

## 2. Tool Definitions (`src/tools/`)

Tools are defined using the Vercel AI SDK's `tool()` helper and Zod schemas.
Each tool is a self-contained module with a description (for the LLM),
an input schema (validated at runtime), and an `execute` function.

### `src/tools/file.ts`

```typescript
// src/tools/file.ts
import { tool } from 'ai';
import { z } from 'zod';
import fs from 'fs/promises';
import path from 'path';

/**
 * Read a file from disk.
 * Pattern: agents-v2/src/agent/tools/file.ts
 */
export const readFile = tool({
  description: 'Read the contents of a file at the specified path.',
  inputSchema: z.object({
    path: z.string().describe('Absolute or relative path to the file'),
  }),
  execute: async ({ path: filePath }) => {
    try {
      return await fs.readFile(filePath, 'utf-8');
    } catch (error) {
      const err = error as NodeJS.ErrnoException;
      if (err.code === 'ENOENT') return `Error: File not found: ${filePath}`;
      return `Error reading file: ${err.message}`;
    }
  },
});

/**
 * Write content to a file. Creates parent directories if needed.
 */
export const writeFile = tool({
  description: 'Write content to a file. Creates the file if it does not exist.',
  inputSchema: z.object({
    path: z.string().describe('Path to the file'),
    content: z.string().describe('Content to write'),
  }),
  execute: async ({ path: filePath, content }) => {
    try {
      await fs.mkdir(path.dirname(filePath), { recursive: true });
      await fs.writeFile(filePath, content, 'utf-8');
      return `Successfully wrote ${content.length} characters to ${filePath}`;
    } catch (error) {
      return `Error writing file: ${(error as Error).message}`;
    }
  },
});

/**
 * List files and directories.
 */
export const listFiles = tool({
  description: 'List all files and directories in the specified path.',
  inputSchema: z.object({
    directory: z.string().default('.').describe('Directory path to list'),
  }),
  execute: async ({ directory }) => {
    try {
      const entries = await fs.readdir(directory, { withFileTypes: true });
      const items = entries.map((e) => {
        const type = e.isDirectory() ? '[dir]' : '[file]';
        return `${type} ${e.name}`;
      });
      return items.length > 0 ? items.join('\n') : `Directory is empty`;
    } catch (error) {
      return `Error: ${(error as Error).message}`;
    }
  },
});
```

### `src/tools/shell.ts`

```typescript
// src/tools/shell.ts
import { tool } from 'ai';
import { z } from 'zod';
import { execSync } from 'child_process';

/**
 * Run a shell command synchronously.
 * In lesson 04, we will upgrade this to async background execution.
 * For now, keep it simple.
 *
 * Pattern: agents-v2/src/agent/tools/shell.ts
 */
export const runCommand = tool({
  description: 'Execute a shell command and return its output.',
  inputSchema: z.object({
    command: z.string().describe('The shell command to execute'),
  }),
  execute: async ({ command }) => {
    try {
      const output = execSync(command, {
        encoding: 'utf-8',
        timeout: 30_000,
        maxBuffer: 1024 * 1024, // 1MB
      });
      return output || 'Command completed successfully (no output)';
    } catch (error: any) {
      return `Command failed (exit code ${error.status}):\n${error.stderr || error.stdout || error.message}`;
    }
  },
});
```

### `src/tools/index.ts` (The Registry)

```typescript
// src/tools/index.ts
import { readFile, writeFile, listFiles } from './file.ts';
import { runCommand } from './shell.ts';

/**
 * All tools combined for the agent.
 * To add a new tool, just import it and add it here.
 *
 * Pattern: agents-v2/src/agent/tools/index.ts
 */
export const tools = {
  readFile,
  writeFile,
  listFiles,
  runCommand,
};

// Export subsets for testing/evals
export const fileTools = { readFile, writeFile, listFiles };
export const shellTools = { runCommand };
```

---

## 3. The Tool Executor (`src/executeTool.ts`)

A tiny dispatcher that looks up a tool by name and runs it.

```typescript
// src/executeTool.ts
import { tools } from './tools/index.ts';

type ToolName = keyof typeof tools;

/**
 * Execute a named tool with the given arguments.
 * Returns the tool's string output.
 *
 * Pattern: agents-v2/src/agent/executeTool.ts
 */
export async function executeTool(
  name: string,
  args: Record<string, unknown>,
): Promise<string> {
  const tool = tools[name as ToolName];

  if (!tool) return `Unknown tool: ${name}`;

  const execute = tool.execute;
  if (!execute) return `Provider tool ${name} — executed by model provider`;

  const result = await execute(args as any, {
    toolCallId: '',
    messages: [],
  });

  return String(result);
}
```

---

## What You Just Built

```
src/
├── types.ts          # Core types + AgentCallbacks interface
├── executeTool.ts    # Tool dispatcher
└── tools/
    ├── index.ts      # Tool registry (single source of truth)
    ├── file.ts       # readFile, writeFile, listFiles
    └── shell.ts      # runCommand
```

**Key patterns to notice:**

1. **Zod schemas** give you runtime validation AND TypeScript types from a single source.
2. **The tool registry** (`tools/index.ts`) is a plain object. Adding a new tool is one import + one line.
3. **The Callbacks interface** decouples the engine from the UI completely.

## Next: Lesson 02

In the next lesson, we will build the **Agent Loop** — the `while(true)` that
calls `streamText()`, processes tool calls, and decides when to stop.
