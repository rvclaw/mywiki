import { useEffect, useState } from "react";
import "./gallary.css";
import "../../globals.css";

type TGalleryProps = {
  images: string[];
};

export function Gallery({ images }: TGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const pre = () =>
    setCurrentIndex((currentIndex) => {
      return Math.max(0, currentIndex - 1);
    });

  const next = () =>
    setCurrentIndex((currentIndex) => {
      return Math.min(images.length - 1, currentIndex + 1);
    });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") pre();
      if (e.key === "ArrowRight") next();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  if (images.length === 0) {
    return (
      <div>
        <p>No images to display</p>
      </div>
    );
  }

  return (
    <section className="container">
      <button className="button" disabled={currentIndex === 0} onClick={pre}>
        pre
      </button>
      <ul
        className="image_list"
        style={{
          transform: `translateX(-${currentIndex * 100}%)`,
        }}
      >
        {images.map((img) => {
          return (
            <li key={img + 1} className="image">
              <img className="" src={img} alt={`image ${img}`} />
            </li>
          );
        })}
      </ul>
      <button
        className="button"
        disabled={currentIndex === images.length - 1}
        onClick={next}
      >
        next
      </button>
    </section>
  );
}

const IMAGES = [
  "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?dpr=1&auto=format&fit=crop&w=1000&q=80&cs=tinysrgb",
  "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?dpr=1&auto=format&fit=crop&w=1000&q=80&cs=tinysrgb",
  "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?dpr=1&auto=format&fit=crop&w=1000&q=80&cs=tinysrgb",
  "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?dpr=1&auto=format&fit=crop&w=1000&q=80&cs=tinysrgb",
];

export const GalleryExample = () => {
  return <Gallery images={IMAGES} />;
};
