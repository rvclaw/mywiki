# Understanding `useSyncExternalStore`

This note explains how `useSyncExternalStore` connects React to the store in
`store.ts`, who supplies the subscription callback, how cleanup happens, and
what React means by **tearing**.

Official reference: <https://react.dev/reference/react/useSyncExternalStore>

## The short mental model

An external store and React have separate responsibilities:

```text
External store owns:
  - the mutable current state
  - a list of listeners
  - a way to read state
  - a way to subscribe and unsubscribe

React owns:
  - rendering components
  - the callback that asks React to check the store again
  - comparing old and new snapshots
  - rerendering when the selected snapshot changed
  - calling unsubscribe during cleanup
```

`useSyncExternalStore` is the protocol joining those two systems:

```ts
const snapshot = useSyncExternalStore(
  subscribe,
  getSnapshot,
  getServerSnapshot?,
);
```

The store does not push state into React. It only sends a notification saying:

> Something may have changed. Read the snapshot again.

React then calls `getSnapshot` and decides whether a rerender is necessary.

## The three store operations

The store in `store.ts` exposes this contract:

```ts
type Store<T> = {
  getState: () => T;
  setState: (action: T | ((previous: T) => T)) => void;
  subscribe: (callback: () => void) => () => void;
};
```

### `getState`

`getState()` returns the current external state. It does not subscribe and it
does not cause a React render.

### `setState`

`setState(...)` computes the next state and then calls every subscribed
listener:

```ts
callbacks.forEach((callback) => callback());
```

Notice that no state is passed to the callback. The callback is only a change
signal. React reads the value separately through `getSnapshot`.

### `subscribe`

`subscribe(callback)` stores a listener and returns the function that removes
that exact listener:

```ts
const subscribe = (callback: () => void) => {
  callbacks.add(callback);

  return () => {
    callbacks.delete(callback);
  };
};
```

The returned function closes over `callback`, so it knows which entry to
delete later.

## Who passes the callback to `store.subscribe`?

Consider this component:

```tsx
const count1 = useSyncExternalStore(
  store.subscribe,
  () => store.getState().count1,
);
```

The component passes the **subscribe function itself** to React. It does not
call `store.subscribe` directly.

Conceptually, React later does something like this:

```ts
const reactNotification = () => {
  // React checks getSnapshot again and schedules work if it changed.
};

const unsubscribe = store.subscribe(reactNotification);
```

`reactNotification` is created and owned by React. It is an internal signal,
not the selected `count1` value and not the component's event handler.

The real React implementation is more sophisticated, but this is the correct
public mental model.

After subscribing, the store's listener set conceptually contains:

```text
callbacks = Set {
  React's notification callback for Component3,
  React's notification callback for another subscriber,
  ...
}
```

## What happens when the store changes?

Suppose `count1` changes from `0` to `1`.

```text
1. Application calls store.setState(...).
2. Store replaces its state.
3. Store invokes all callbacks.
4. React's callback tells React the store may have changed.
5. React calls getSnapshot(): () => store.getState().count1.
6. React compares the old snapshot and new snapshot with Object.is.
7. Object.is(0, 1) is false, so React rerenders Component3.
```

The flow is:

```text
store.setState
      |
      v
notify React callback
      |
      v
React calls getSnapshot
      |
      v
Object.is(previousSnapshot, nextSnapshot)
      |
      +-- same ------> skip rerender
      |
      +-- different -> rerender
```

If only `count2` changes, this snapshot still returns the same primitive:

```ts
() => store.getState().count1
```

React is notified, but `Object.is(previousCount1, nextCount1)` is `true`, so
the component selecting `count1` does not need to rerender.

## How unsubscribe is called on unmount

React remembers the cleanup function returned by `store.subscribe`:

```ts
const unsubscribe = store.subscribe(reactNotification);
```

When the component unmounts, React conceptually calls:

```ts
unsubscribe();
```

That executes the closure returned by this store:

```ts
() => {
  callbacks.delete(reactNotification);
}
```

The complete lifecycle is:

```text
Component commits
      |
      v
React calls store.subscribe(reactNotification)
      |
      v
Store adds reactNotification to callbacks
      |
      v
Store returns unsubscribe to React
      |
      v
Component remains subscribed while mounted
      |
      v
Component unmounts
      |
      v
React calls unsubscribe
      |
      v
Store deletes reactNotification
```

React also unsubscribes and resubscribes if the `subscribe` function identity
changes between renders. In development Strict Mode, React may intentionally
exercise a setup -> cleanup -> setup sequence to reveal broken cleanup logic.

This is why `subscribe` must return cleanup and why its function identity
should normally be stable. In this project, `store.subscribe` is created once
by `createStore`, so its identity is stable.

Do not confuse this with tearing. Unmounting is normal lifecycle cleanup.

## What tearing actually means

**Tearing is not a component failing to unsubscribe on unmount.**

Tearing means different components in one committed screen display snapshots
from different versions of the same external store.

Imagine two components reading one store during a concurrent render:

```text
Store version A: { count1: 0, count2: 0 }
Store version B: { count1: 1, count2: 1 }
```

Without the external-store protocol, this could happen:

```text
1. React starts rendering ComponentA.
2. ComponentA reads store version A: count1 = 0.
3. React pauses that render.
4. External code updates the store to version B.
5. React renders ComponentB.
6. ComponentB reads store version B: count2 = 1.
7. React commits both results together.
```

The user would see an impossible mixture:

```text
ComponentA: count1 = 0  (version A)
ComponentB: count2 = 1  (version B)
```

That mixed screen is tearing:

```text
One committed UI
  |-- ComponentA shows store version A
  `-- ComponentB shows store version B
```

The UI has been "torn" between two points in time.

## How `useSyncExternalStore` prevents tearing

React controls when it reads snapshots and verifies that they are still
current before committing work.

Conceptually:

```text
1. Read snapshot while rendering.
2. The external store changes during the render.
3. Read/check the snapshot again before committing.
4. Detect that it no longer matches.
5. Restart the work so the committed UI uses one current store version.
```

For a non-blocking Transition, React may check `getSnapshot` again just before
changing the DOM. If the value changed, React restarts that update as blocking
work so every visible subscriber is consistent.

This guarantee depends on the store obeying the snapshot contract.

## The snapshot contract

Repeated calls to `getSnapshot` must return the same value while the relevant
store data has not changed.

This selector is safe:

```ts
() => store.getState().count1
```

It returns a primitive number. If `count1` is unchanged, the number compares
equal with `Object.is`.

Returning the immutable store object is also safe if `setState` replaces the
object and `getState` returns the same object until the next update:

```ts
store.getState
```

This selector is unsafe without caching:

```ts
() => ({ count1: store.getState().count1 })
```

It creates a new object on every call:

```ts
Object.is({ count1: 1 }, { count1: 1 }); // false
```

React can interpret every read as another change and report:

```text
The result of getSnapshot should be cached
```

The rule is:

> Same underlying selected data -> same snapshot according to Object.is.

## Why the store should update immutably

The examples replace the store state:

```ts
store.setState((previous) => ({
  ...previous,
  count1: previous.count1 + 1,
}));
```

This produces a new state object. The old object remains an immutable snapshot
of the previous store version.

Mutating the existing object in place makes snapshot identity unreliable:

```ts
const current = store.getState();
current.count1 += 1;
store.setState(current);
```

The object reference is unchanged even though its contents changed. A
whole-state snapshot using `store.getState` could compare equal and React may
not know it needs to rerender. Prefer replacement updates for this store.

## Why subscription callbacks receive no state

This design is intentional:

```ts
subscribe: (callback: () => void) => () => void;
```

The callback means "possibly changed", not "here is the next state".

Separating notification from reading lets React:

- read a coherent snapshot during rendering;
- read it more than once to check consistency;
- select only the data a component needs;
- compare snapshots using `Object.is`;
- avoid trusting a value pushed at an unsafe moment.

The source of truth remains `getSnapshot`, not the callback argument.

## A reusable selector Hook

Instead of repeating `useSyncExternalStore` in every component, the store can
provide a typed selector Hook:

```ts
export function useStoreSelector<T, S>(
  store: Store<T>,
  selector: (state: T) => S,
): S {
  const getSnapshot = useCallback(
    () => selector(store.getState()),
    [store, selector],
  );

  return useSyncExternalStore(store.subscribe, getSnapshot);
}
```

A stable selector can be declared outside the component:

```ts
const selectCount1 = (state: { count1: number }) => state.count1;

function Component1() {
  const count1 = useStoreSelector(store, selectCount1);
  return <div>{count1}</div>;
}
```

Declaring the selector outside avoids creating a new function on every render.
For a primitive selector such as `count1`, repeated snapshots are naturally
stable.

## The inline `getSnapshot` in Component3

The current example uses:

```tsx
const count1 = useSyncExternalStore(
  store.subscribe,
  () => store.getState().count1,
);
```

The inline `getSnapshot` function has a new identity on every render, but the
documented resubscription rule is specifically about the `subscribe` function.
`store.subscribe` remains stable here. The returned snapshot is a primitive
and remains equal while `count1` is unchanged.

Extracting `getSnapshot` can still make the contract easier to read:

```ts
const getCount1Snapshot = () => store.getState().count1;
```

Then:

```ts
const count1 = useSyncExternalStore(
  store.subscribe,
  getCount1Snapshot,
);
```

## Server rendering and hydration

The optional third argument is for server rendering:

```ts
useSyncExternalStore(
  subscribe,
  getSnapshot,
  getServerSnapshot,
);
```

`getServerSnapshot` runs:

- while rendering HTML on the server; and
- during hydration's initial client render.

Those two snapshots must match. If this application is client-only, the third
argument can be omitted. If a component using the Hook is server-rendered and
the argument is omitted, React throws because it cannot produce a safe server
snapshot.

## Comparison with the manual `useEffect` Hook

The manual `useStoreSelector` currently has to manage:

```text
1. React state for the selected snapshot.
2. Effect subscription.
3. Copying the external state into React state.
4. Reading again after subscribing to close the missed-update gap.
5. Returning unsubscribe.
```

That implementation teaches the mechanism, but it does not give React the
full concurrent snapshot protocol. `useSyncExternalStore` should be preferred
for an actual external store because it handles subscription timing and
snapshot consistency with React's renderer.

## A subscription in the current example that never cleans up

`CounterWithStore.tsx` currently contains a module-level subscription like:

```ts
const unsubs = store.subscribe(() => store.getState());
```

This subscription is outside React. React did not create it, so React will not
clean it up. The returned `unsubs` function must be called by the code that
owns that subscription. Its callback also reads the state and discards the
result, so it currently has no useful effect.

This differs from `useSyncExternalStore`, where React owns the subscription
and automatically calls the returned cleanup function.

## Common mistakes checklist

### Forgetting to return unsubscribe

```ts
subscribe(callback) {
  listeners.add(callback);
  // Missing cleanup: listener leaks.
}
```

### Calling unsubscribe immediately

The store must return the function, not invoke it during subscription:

```ts
return unsubscribe;   // correct
return unsubscribe(); // wrong
```

### Passing a changing `subscribe` function

Defining `subscribe` inside a component creates a new function every render,
so React must clean up and resubscribe. Prefer a function owned by the stable
store object.

### Returning a fresh object from `getSnapshot`

Fresh objects compare unequal even when their contents match. Return immutable
store data or a cached selected snapshot.

### Mutating the snapshot in place

Replacing state gives each store version a stable identity. In-place mutation
can make a changed value look unchanged to `Object.is`.

### Assuming notification means rerender

Notification only makes React check again. React rerenders only when the new
snapshot differs from the previous snapshot.

### Confusing unmount cleanup with tearing

- Unmount cleanup removes a listener that is no longer needed.
- Tearing is one committed UI showing multiple store versions.

They are different problems, though `useSyncExternalStore` participates in
solving both subscription cleanup and consistent external snapshots.

## Final model to remember

```text
Render:
  React calls getSnapshot and remembers its value.

Commit/subscription:
  React passes its own callback to store.subscribe.
  The store saves it and returns unsubscribe.

Store update:
  The store changes state and invokes listeners.
  React calls getSnapshot again.
  React compares snapshots with Object.is.
  React rerenders only if the snapshot changed.

Unmount/resubscribe:
  React calls the unsubscribe function returned by the store.

Concurrent consistency:
  React rechecks snapshots before committing when necessary.
  If the external value changed during rendering, React restarts work rather
  than committing a screen torn between store versions.
```
