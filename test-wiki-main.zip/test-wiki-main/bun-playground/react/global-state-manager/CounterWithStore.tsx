import { createStore, useStore, useStoreSelector } from "./store";

const store = createStore({
  count: 0,
});
const store2 = createStore({ count: 0 });

export function CounterWithStore() {
  return (
    <div>
      <h1>Counters</h1>
      <hr />
      counter one
      <Counter />
      <Counter />
      <hr />
      counter two
      <Component2 />
    </div>
  );
}

const Component2 = () => (
  <>
    <Counter2 />
    <Counter2 />
  </>
);
const Counter = () => {
  const [state, setState] = useStore(store);
  const inc = () => {
    setState((prev) => ({
      ...prev,
      count: prev.count + 1,
    }));
  };
  return (
    <div>
      {state.count} <button onClick={inc}>+1</button>
    </div>
  );
};

const Counter2 = () => {
  const [state, setState] = useStore(store2);
  const inc = () => {
    setState((prev) => ({
      ...prev,
      count: prev.count + 1,
    }));
  };
  return (
    <div>
      {state.count} <button onClick={inc}>+1</button>
    </div>
  );
};

// const Component3 = () => {
//   const count1 = useStoreSelector(store, () => store.getState());

//   return (
//     <div>
//       <b>I am reading count1: {JSON.stringify(count1)}</b>
//     </div>
//   );
// };
// const Component1 = () => {
//   const count1 = useStoreSelector(store, (state) => state.count1);
//   const inc = () => {
//     store.setState((prev) => {
//       return {
//         ...prev,
//         count1: prev.count1 + 1,
//       };
//     });
//   };
//   return (
//     <div>
//       {count1} <button onClick={inc}>+1</button>
//     </div>
//   );
// };
// const Component2 = () => {
//   const state = useStoreSelector(store, (state) => state.count2);
//   const inc2 = () => {
//     store.setState((prev) => {
//       return {
//         ...prev,
//         count2: prev.count2 + 2,
//       };
//     });
//   };
//   return (
//     <div>
//       {state} <button onClick={inc2}>+2</button>
//     </div>
//   );
// };
