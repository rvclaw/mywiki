import { useEffect, useState } from "react";

type UseQueryArgs<T> = {
  queryKeys: string[];
  queryFunc: () => Promise<T>;
  initialData: T;
};

export function useQuery<T>({
  queryFunc,
  queryKeys,
  initialData,
}: UseQueryArgs<T>) {
  const [data, setData] = useState<T>(initialData);

  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    let didCancel = false;
    const fetchData = async () => {
      setIsError(false);
      setIsLoading(true);
      try {
        const result = await queryFunc();
        if (!didCancel) setData(result);
      } catch (error) {
        if (!didCancel) setIsError(true);
      }
      setIsLoading(false);
    };
    fetchData();
    return () => {
      didCancel = true;
    };
  }, [...queryKeys]);
  return { data, isError, isLoading };
}
