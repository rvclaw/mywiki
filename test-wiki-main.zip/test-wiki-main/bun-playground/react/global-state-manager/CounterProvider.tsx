import {
  createContext,
  useRef,
  type ReactNode,
  useCallback,
  useSyncExternalStore,
  use,
} from "react";
import { createStore, type Store } from "./store";

export type State = { count: number; text?: string };

const StoreContext = createContext<Store<State>>(
  createStore<State>({ count: 0, text: "hello" }),
);

export const StoreProvider = ({
  initialState,
  children,
}: {
  initialState: State;
  children: ReactNode;
}) => {
  const storeRef = useRef<Store<State>>(null);
  if (!storeRef.current) {
    storeRef.current = createStore(initialState);
  }
  return <StoreContext value={storeRef.current}>{children}</StoreContext>;
};

export const useSelector = <S extends unknown>(
  selector: (state: State) => S,
) => {
  const store = use(StoreContext);

  const getSnapshot = useCallback(() => {
    return selector(store.getState());
  }, [selector, store]);
  const state = useSyncExternalStore(store.subscribe, getSnapshot);
  return state;
};

export const useSetState = () => {
  const store = use(StoreContext);
  return store.setState;
};
