import { useEffect, useState } from "react";
import { useQuery } from "./useQuery";

const API = "https://hn.algolia.com/api/v1/search";
type Story = {
  objectID: string;
  title: string;
  url: string;
};

export function DataFetching() {
  const [search, setSearch] = useState("");
  const [activeSearch, setActiveSearch] = useState("");

  const { data, isError, isLoading } = useQuery<Story[]>({
    queryKeys: [activeSearch],
    queryFunc: async () => {
      const res = await fetch(`${API}?query=${activeSearch}`);
      const result = await res.json();
      return result.hits;
    },
    initialData: [],
  });

  const handleSearchSubmit = (event: React.SubmitEvent<HTMLFormElement>) => {
    setActiveSearch(search);
    setSearch("");
    event.preventDefault();
  };

  return (
    <div>
      <div>
        <form onSubmit={handleSearchSubmit}>
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
            }}
          />
          <button type="submit">search</button>
        </form>
      </div>

      {isError && <div>Something went wrong ...</div>}

      <ul>
        {isLoading ? (
          <h2>Loading...</h2>
        ) : (
          data.map((d) => (
            <li key={d.objectID}>
              <a href={d.url}>{d.title}</a>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}
