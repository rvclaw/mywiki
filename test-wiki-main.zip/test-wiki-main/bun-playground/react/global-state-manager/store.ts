//what is module state how is different from react state?

import { useCallback, useEffect, useState, useSyncExternalStore } from "react";

type StateUpdater<T> = (prev: T) => T;
type SetStateAction<T> = T | StateUpdater<T>;

export type Store<T> = {
  getState: () => T;
  setState: (action: SetStateAction<T>) => void;
  subscribe: (callback: () => void) => () => void;
};

export function createStore<T extends unknown>(initialState: T): Store<T> {
  let state = initialState;
  const callbacks = new Set<() => void>();
  const getState = () => {
    return state;
  };

  const setState = (nextState: T | ((prev: T) => T)) => {
    state =
      typeof nextState === "function"
        ? (nextState as (prev: T) => T)(state)
        : nextState;
    callbacks.forEach((callback) => callback());
  };

  const subscribe = (callback: () => void) => {
    callbacks.add(callback);
    return () => {
      callbacks.delete(callback);
    };
  };
  return {
    getState,
    setState,
    subscribe,
  };
}

export function useStore<T>(store: Store<T>): [T, Store<T>["setState"]] {
  const [state, setState] = useState(store.getState());

  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      setState(store.getState());
    });
    setState(store.getState());
    return unsubscribe;
  }, [store]);
  return [state, store.setState];
}

// export function useStoreSelector<T, S>(
//   store: Store<T>,
//   selector: (state: T) => S,
// ) {
//   const [state, setState] = useState(() => selector(store.getState()));
//   useEffect(() => {
//     const unsubscribe = store.subscribe(() => {
//       setState(selector(store.getState()));
//     });
//     setState(selector(store.getState()));
//     return unsubscribe;
//   }, [selector, store]);
//   return state;
// }

export function useStoreSelector<T, S>(
  store: Store<T>,
  selector: (state: T) => S,
): S {
  const getSnapshot = useCallback(() => {
    return selector(store.getState());
  }, [selector, store]);
  const state = useSyncExternalStore(store.subscribe, getSnapshot);
  return state;
}
