import { useEffect, useReducer } from "react";

const initialState = {
  count: 0,
  step: 1,
};

type State = typeof initialState;

type Action =
  | {
      mytype: "tick";
    }
  | {
      mytype: "step";
      step: number;
    };

function reducer(state: State, action: Action) {
  if (action.mytype === "tick") {
    return { count: state.count + state.step, step: state.step };
  }
  if (action.mytype === "step") {
    return { count: state.count, step: action.step };
  } else {
    throw new Error("undefined action");
  }
}

export function Counter() {
  const [state, dispatch] = useReducer(reducer, initialState);

  const { step, count } = state;

  useEffect(() => {
    const id = setInterval(() => {
      dispatch({
        mytype: "tick",
      });
    }, 1000);
    return () => clearInterval(id);
  }, [dispatch]);

  return (
    <div className="" style={{}}>
      <h1>{count}</h1>
      <input
        value={step}
        onChange={(e) => {
          dispatch({
            mytype: "step",
            step: Number(e.target.value),
          });
        }}
      />
    </div>
  );
}
