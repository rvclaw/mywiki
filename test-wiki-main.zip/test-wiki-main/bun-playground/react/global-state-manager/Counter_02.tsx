import { useState } from "react";
import { useInterval } from "./useInterval";

export function CounterWithInterval() {
  const [count, setCount] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  function callback() {
    setCount((preV) => preV + 1);
  }

  useInterval(callback, isPaused ? 500 : null);

  return (
    <div>
      <h1>{count}</h1>
    </div>
  );
}
