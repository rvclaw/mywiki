import { useEffect, useRef } from "react";

export function useInterval(callback: () => void, delay: number | null = 2000) {
  const callBackRef = useRef(callback);

  useEffect(() => {
    callBackRef.current = callback;
  });

  useEffect(() => {
    function tick() {
      callBackRef.current();
    }
    if (delay !== null) {
      const intervalId = setInterval(tick, delay);
      return () => clearInterval(intervalId);
    }
  }, [delay]);
}
