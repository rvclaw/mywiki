import { useState } from "react";
import { createRoot } from "react-dom/client";
import { CounterWithStore } from "./react/global-state-manager/CounterWithStore";
import { CounterWithContextStore } from "./react/global-state-manager/CounterWithContextStore";

function App() {
  return (
    <main
      style={{
        fontFamily: "system-ui",
        height: "100%",
        width: "100%",
        margin: 0,
        padding: 0,
      }}
    >
      <CounterWithContextStore />
    </main>
  );
}

const root = document.getElementById("root")!;
createRoot(root).render(<App />);
