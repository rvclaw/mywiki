// Workaround for Bun #20902: manual class map for the utility classes we use.

export default {
  maxW600px: "maxW600px",
  flexColumnGap12: "flexColumnGap12",
  flexRowBetween: "flexRowBetween",
  paddingHor16: "paddingHor16",
  paddingVer12: "paddingVer12",
  fontXL: "fontXL",
  paddingVer16: "paddingVer16",
} as const;
