import React, { useEffect, useRef, useState } from "react";
import "./styles.module.css";

type TDialogProps = {
  open: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  children: React.ReactNode;
};

export function Dialog({ open, onCancel, onConfirm, children }: TDialogProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open) {
      dialog.showModal();
    } else {
      dialog.close();
    }
  }, [open]);

  return (
    <dialog
      ref={dialogRef}
      className="padding24 bNone br8 container"
      onClose={onCancel}
    >
      <section className="paddingVer8 ">{children}</section>
      <footer className="flexRowBetween flexGap8 paddingVer8">
        <button autoFocus onClick={onConfirm}>
          confirm
        </button>
        <button onClick={onCancel}>cancel</button>
      </footer>
    </dialog>
  );
}

export function DialogExample() {
  const [open, setOpen] = useState(false);

  const handleConfirm = () => {
    alert("Confirmed");
    setOpen(false);
  };
  const handleCancel = () => {
    alert("Cancelled");
    setOpen(false);
  };

  return (
    <div>
      <button onClick={() => setOpen(true)}>Open Dialog</button>
      <Dialog open={open} onConfirm={handleConfirm} onCancel={handleCancel}>
        <h2>Confirm Action</h2>
        <p>Are you sure you want to proceed?</p>
      </Dialog>
    </div>
  );
}
