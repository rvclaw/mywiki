// Workaround for Bun #20902: CSS Modules fail with Bun.serve() + HTML bundler.
// This file mirrors what `import styles from "./accordion.module.css"` would return.

export default {
  container: "container",
  details: "details",
  summary: "summary",
  content: "content",
} as const;
