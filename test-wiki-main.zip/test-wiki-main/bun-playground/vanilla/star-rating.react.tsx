import { useCallback } from "react";
import cx from "./cx";
import "./star-rating.css";
import "./styles.module.css";

const EMOJIS = ["⭐️", "⭐️", "⭐️", "⭐️", "⭐️"] as const;

type TStarRatingProps = {
  readOnly?: boolean;
  value: number;
  onChange: (value: number) => void;
};

export const StarRatingComponent = ({
  readOnly,
  value,
  onChange,
}: TStarRatingProps) => {
  const handleStarClick = useCallback(
    (event: React.MouseEvent) => {
      if (readOnly) return;
      const button = (event.target as HTMLElement).closest("button");
      if (!button) return;
      const starValue = Number(button.dataset.starValue);
      if (!Number.isNaN(starValue)) {
        onChange(starValue);
      }
    },
    [readOnly],
  );

  return (
    <div className={cx()} onClick={handleStarClick}>
      <input type="number" value={value} readOnly hidden />
      <div>
        {EMOJIS.map((emoji, index) => {
          const starValue = index + 1;
          return (
            <button
              type="button"
              role="radio"
              aria-checked={value === starValue}
              data-star-value={starValue}
              className="flexColumnCenter fontXL star"
              key={index}
              data-active={value >= starValue}
              disabled={readOnly}
            >
              <span>{emoji}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
