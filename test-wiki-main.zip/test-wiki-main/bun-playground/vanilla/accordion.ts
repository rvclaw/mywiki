import { AbstractComponent, type TComponentConfig } from "./abstract_component";
import cx from "./cx";

// CSS imported for side-effect bundling only (Bun bug #20902 prevents
// importing CSS Modules as objects via Bun.serve + HTML bundler).
import "./accordion.module.css";
import "./styles.module.css";
import styles from "./accordion.css-module";
import flex from "./utils.css-module";

type TAccordionProps = {
  items: TAccordionItem[];
};
export type TAccordionItem = {
  id: string;
  title: string;
  content: string;
};

export class Accordion extends AbstractComponent<TAccordionProps> {
  constructor(config: TComponentConfig<TAccordionProps>) {
    super({
      ...config,
      className: [
        styles.container,
        flex.maxW600px,
        flex.flexColumnGap12,
        ...(config.className || []),
      ],
    });
  }

  toHTML(): string {
    return this.config.items
      .map((item) => {
        return `
                <details class="${styles.details}">
                    <summary class="${cx(styles.summary, flex.flexRowBetween, flex.paddingHor16, flex.paddingVer12, flex.fontXL)}">${item.title}</summary>
                    <p class="${cx(styles.content, flex.paddingVer16, flex.paddingHor16)}">${item.content}</p>
                </details>
            `;
      })
      .join("");
  }
}

const LOREM =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. ";

const LARGE_CONTENT = Array(2).fill(LOREM).join("");

const MOCK_DATA: TAccordionItem[] = [
  { id: "1", title: "Section 1", content: LARGE_CONTENT },
  { id: "2", title: "Section 2", content: LARGE_CONTENT },
  { id: "3", title: "Section 3", content: LARGE_CONTENT },
  { id: "4", title: "Section 4", content: LARGE_CONTENT },
  { id: "5", title: "Section 5", content: LARGE_CONTENT },
];

const accordion = new Accordion({
  root: document.getElementById("app")!,
  items: MOCK_DATA,
});

accordion.render();

if (import.meta.hot) {
  import.meta.hot.accept();
}
