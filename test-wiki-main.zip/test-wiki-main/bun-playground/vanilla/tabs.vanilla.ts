import { AbstractComponent, type TComponentConfig } from "./abstract_component";
import cx from "./cx";
import "./styles.module.css";
import "./tabs.css";

export type TTabProps = {
  name: string;
  content: string;
};

export type TTabsProps = {
  target?: HTMLElement;
  defaultTab?: string;
  tabs: TTabProps[];
};

export class VanillaTabs extends AbstractComponent<TTabsProps> {
  #defaultTab: string;
  #contentContainer: HTMLElement | null = null;
  #activeTabName: string | undefined;

  constructor(config: TComponentConfig<TTabsProps>) {
    super({
      ...config,
      listeners: ["click"],
    });
    this.#defaultTab = config.defaultTab || config.tabs[0].name;
  }
  toHTML(): string {
    const { className, target } = this.config;
    const classes = cx(...(className ?? []));
    const contentHtml = target
      ? ""
      : `<section role="tabpanel" id="tab-panel" aria-labelledby="tab-${this.#defaultTab}" class="container"></section>`;

    return `
            <nav class="${classes}">
                <ul role="tablist" class="flexRowStart flexGap16">
                    ${this.#getTabs()}
                </ul>
            </nav>
            ${contentHtml}
        `;
  }
  afterRender(): void {
    if (!this.config.target) {
      this.#contentContainer = this.container!.querySelector(`.container`);
    }
    this.#activateTab(this.#defaultTab);
  }

  onClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    const button = target.closest("button");

    if (!button) return;

    const tabName = button.dataset.tabName;
    if (tabName && tabName !== this.#activeTabName) {
      this.#activateTab(tabName);
    }
  }

  #activateTab(tabName: string): void {
    const tab = this.config.tabs.find((t) => t.name === tabName);
    if (!tab) return;

    // Update aria-selected on all tab buttons
    const buttons = this.container?.querySelectorAll('[role="tab"]');
    buttons?.forEach((btn) => {
      const isActive = (btn as HTMLElement).dataset.tabName === tabName;
      btn.setAttribute("aria-selected", String(isActive));
    });

    this.#activeTabName = tabName;
    const { content } = tab;

    // Update target container (external or internal)
    const container = this.config.target || this.#contentContainer;
    if (container) {
      container.innerHTML = content;
      container.setAttribute("aria-labelledby", `tab-${tabName}`);
    }
  }
  #getTabs(): string {
    const { tabs } = this.config;
    return tabs
      .map(
        (tab) =>
          `<li role="presentation"><button role="tab" id="tab-${tab.name}" data-tab-name="${tab.name}" aria-controls="tab-panel" aria-selected="false">${tab.name}</button></li>`,
      )
      .join("");
  }
}

const VANILLA_TABS = [
  {
    name: "Overview",
    content: `
      <h3>Project Overview</h3>
      <p>This project demonstrates a tab component built from scratch using vanilla TypeScript and the AbstractComponent pattern.</p>
      <ul>
        <li><strong>Framework:</strong> None — pure TypeScript</li>
        <li><strong>Pattern:</strong> AbstractComponent with event delegation</li>
        <li><strong>Styling:</strong> CSS Modules</li>
      </ul>
      <p>The component supports dynamic tab switching, external content targets, and keyboard navigation.</p>
    `,
  },
  {
    name: "Features",
    content: `
      <h3>Key Features</h3>
      <ol>
        <li><strong>Click-based navigation</strong> — switch between tabs by clicking tab buttons</li>
        <li><strong>Default tab selection</strong> — specify which tab is active on mount</li>
        <li><strong>External target</strong> — optionally render content into a separate DOM element</li>
        <li><strong>Event delegation</strong> — a single click listener on the container handles all tab clicks</li>
        <li><strong>Destroy lifecycle</strong> — clean up event listeners and DOM nodes on unmount</li>
      </ol>
      <blockquote>
        <p><em>"Simplicity is the ultimate sophistication."</em> — Leonardo da Vinci</p>
      </blockquote>
    `,
  },
  {
    name: "API",
    content: `
      <h3>Component API</h3>
      <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; width: 100%;">
        <thead>
          <tr><th>Prop</th><th>Type</th><th>Description</th></tr>
        </thead>
        <tbody>
          <tr><td><code>tabs</code></td><td><code>TTabProps[]</code></td><td>Array of tab objects with <code>name</code> and <code>content</code></td></tr>
          <tr><td><code>defaultTab</code></td><td><code>string?</code></td><td>Name of the initially active tab</td></tr>
          <tr><td><code>target</code></td><td><code>HTMLElement?</code></td><td>External element to render content into</td></tr>
          <tr><td><code>root</code></td><td><code>HTMLElement</code></td><td>Container element for the component</td></tr>
          <tr><td><code>className</code></td><td><code>string[]</code></td><td>Additional CSS classes for the container</td></tr>
        </tbody>
      </table>
    `,
  },
  {
    name: "Usage",
    content: `
      <h3>Usage Example</h3>
      <pre><code>const tabs = new Tabs({
  root: document.getElementById('app'),
  className: [],
  tabs: [
    { name: 'Tab 1', content: '&lt;p&gt;Hello&lt;/p&gt;' },
    { name: 'Tab 2', content: '&lt;p&gt;World&lt;/p&gt;' },
  ],
  defaultTab: 'Tab 1',
})

tabs.render()

// Later, clean up:
tabs.destroy()</code></pre>
      <h4>Notes</h4>
      <ul>
        <li>Call <code>render()</code> after construction to mount the component</li>
        <li>Call <code>destroy()</code> to remove event listeners and DOM nodes</li>
        <li>Re-calling <code>render()</code> will destroy and re-create the component</li>
      </ul>
    `,
  },
  {
    name: "Changelog",
    content: `
      <h3>Changelog</h3>
      <dl>
        <dt><strong>v1.2.0</strong> — March 2026</dt>
        <dd>Added external target support and keyboard navigation</dd>
        <dt><strong>v1.1.0</strong> — February 2026</dt>
        <dd>Refactored to use AbstractComponent base class</dd>
        <dt><strong>v1.0.0</strong> — January 2026</dt>
        <dd>Initial release with basic tab switching</dd>
      </dl>
    `,
  },
];

const tabs = new VanillaTabs({
  root: document.getElementById("app")!,
  className: [],
  tabs: VANILLA_TABS,
  defaultTab: "Overview",
});

tabs.render();
