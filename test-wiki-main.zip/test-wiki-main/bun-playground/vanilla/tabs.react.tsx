import {
  useId,
  useState,
  Children,
  isValidElement,
  type PropsWithChildren,
  type ReactElement,
  type ReactNode,
  type RefObject,
  type KeyboardEvent,
} from "react";
import { createPortal } from "react-dom";
import cx from "./cx";
import "./tabs.css";
import "./styles.module.css";

/* ------------------------------------------------------------------ */
/* Tab                                                                 */
/* ------------------------------------------------------------------ */

export type TTabProps = PropsWithChildren<{
  name: string;
}>;

// The Tab component only declares a tab; its `children` are the panel content,
// which <Tabs> reads. It renders nothing on its own.
export function Tab(_props: TTabProps): null {
  return null;
}

/* ------------------------------------------------------------------ */
/* Tabs                                                                */
/* ------------------------------------------------------------------ */

type TTabsProps = {
  target?: RefObject<HTMLElement | null>;
  defaultTab?: string;
  children: ReactNode;
};

function isTabElement(node: ReactNode): node is ReactElement<TTabProps> {
  return isValidElement(node) && node.type === Tab;
}

export function Tabs({ defaultTab, children, target }: TTabsProps) {
  const baseId = useId();

  // Collect Tab children robustly (handles single child, fragments, falsy).
  const tabs = Children.toArray(children).filter(isTabElement);

  const [activeTab, setActiveTab] = useState<string>(
    defaultTab ?? tabs[0]?.props.name ?? "",
  );

  const tabNames = tabs.map((t) => t.props.name);
  const activeContent = tabs.find((t) => t.props.name === activeTab)?.props
    .children;

  const tabId = (name: string) => `${baseId}-tab-${name}`;
  const panelId = `${baseId}-panel`;

  // Roving arrow-key navigation per WAI-ARIA tabs pattern.
  const handleKeyDown = (event: KeyboardEvent<HTMLUListElement>) => {
    const currentIndex = tabNames.indexOf(activeTab);
    if (currentIndex === -1) return;

    let nextIndex: number | null = null;
    switch (event.key) {
      case "ArrowRight":
        nextIndex = (currentIndex + 1) % tabNames.length;
        break;
      case "ArrowLeft":
        nextIndex = (currentIndex - 1 + tabNames.length) % tabNames.length;
        break;
      case "Home":
        nextIndex = 0;
        break;
      case "End":
        nextIndex = tabNames.length - 1;
        break;
      default:
        return;
    }

    event.preventDefault();
    const nextName = tabNames[nextIndex];
    setActiveTab(nextName);
    // Move focus to the newly active tab (roving tabindex).
    document.getElementById(tabId(nextName))?.focus();
  };

  const handleClick = (event: React.MouseEvent<HTMLUListElement>) => {
    const button = (event.target as HTMLElement).closest("button");
    const name = button?.dataset.tabName;
    if (name) setActiveTab(name);
  };

  const panel = (
    <section
      role="tabpanel"
      id={panelId}
      aria-labelledby={tabId(activeTab)}
      tabIndex={0}
      className="container"
    >
      {activeContent}
    </section>
  );

  return (
    <div>
      <nav>
        <ul
          role="tablist"
          aria-label="Tabs"
          onClick={handleClick}
          onKeyDown={handleKeyDown}
          className={cx("flexRowStart", "flexGap16")}
        >
          {tabNames.map((name) => {
            const isActive = name === activeTab;
            return (
              <li role="presentation" key={name}>
                <button
                  role="tab"
                  id={tabId(name)}
                  data-tab-name={name}
                  aria-selected={isActive}
                  aria-controls={panelId}
                  tabIndex={isActive ? 0 : -1}
                >
                  {name}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {target?.current
        ? createPortal(panel, target.current)
        : panel}
    </div>
  );
}
