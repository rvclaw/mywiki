import {
  AbstractComponent,
  type TComponentConfig,
} from "./abstract_component.ts";
import "./button.css";

class Counter extends AbstractComponent<{ initial: number }> {
  count: number;

  constructor(config: TComponentConfig<{ initial: number }>) {
    super({ ...config, listeners: ["click"] });
    this.count = config.initial;
  }

  toHTML() {
    return `
      <button data-action="decrement">-</button>
      <span>${this.count}</span>
      <button data-action="increment"  class="button">+</button>
    `;
  }

  onClick(e: Event) {
    const action = (e.target as HTMLElement).dataset.action;
    if (action === "increment") this.count++;
    if (action === "decrement") this.count--;
    this.render(); // Re-render on state change
  }
}

// Usage
const counter = new Counter({
  root: document.getElementById("app")!,
  initial: 0,
});
counter.render();
