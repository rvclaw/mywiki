import { AbstractComponent, type TComponentConfig } from "./abstract_component";
import "./styles.module.css";
import "./star-rating.css";

type TStarRatingProps = {
  value: number;
  onValueChange: (value: number) => void;
  readonly?: boolean;
};

const STAR = "⭐";
const STARS_COUNT = 5;

export class StarRating extends AbstractComponent<TStarRatingProps> {
  private value: number = 0;

  constructor(config: TComponentConfig<TStarRatingProps>) {
    super({
      ...config,
      className: ["container"],
      listeners: ["click"],
    });
    this.value = config.value;
  }

  onClick(event: MouseEvent): void {
    if (this.config.readonly) return;
    const button = (event.target as HTMLElement).closest("button");
    if (!button) return;

    console.log("clicked");

    const starValue = Number(button.dataset.starValue);
    if (!Number.isNaN(starValue)) {
      this.value = starValue;
      this.config.onValueChange(starValue);
      this.render();
    }
  }

  toHTML(): string {
    const readonly = this.config.readonly ?? false;
    const stars = Array.from({ length: STARS_COUNT }, (_, index) => {
      const starValue = index + 1;
      return `
            <button
            aria-readonly="${readonly}"
            data-star-value="${starValue}"
            class="star flexColumnCenter fontXL"
            aria-label="${starValue} Star${starValue === 1 ? "" : "s"}"
            aria-checked="${this.value === starValue}"
            role="radio"
            type="button"
            data-active="${this.value >= starValue}"
            ${readonly ? "disabled" : ""}
            >
            <span>${STAR}</span>
            </button>      
        `;
    }).join("");

    return `
    <input
    type="number"
    value="${this.value}"
    readonly hidden
    />
    <div
    class="flexRowCenter"
    >
    ${stars}
    </div>
    `;
  }
  afterRender(): void {
    if (!this.container) return;
    this.container.setAttribute("role", "radiogroup");
    this.container.setAttribute("aria-label", "Star Rating");
    this.container.setAttribute(
      "aria-readonly",
      String(this.config.readonly ?? false),
    );
  }
}

const starRating = new StarRating({
  root: document.getElementById("app")!,
  className: ["star-rating"],
  value: 0,
  readonly: false,
  onValueChange: () => {},
});

starRating.render();

if (import.meta.hot) {
  import.meta.hot.accept();
}
