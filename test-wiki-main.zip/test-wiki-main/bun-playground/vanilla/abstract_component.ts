export type TComponentConfig<T> = T & {
  root: HTMLElement;
  className?: string[];
  listeners?: string[];
  tag?: keyof HTMLElementTagNameMap;
};

const DEFAULT_CONFIG: Partial<TComponentConfig<any>> = {
  className: [],
  listeners: [],
  tag: "div",
};

const toEventName = (type: string): string => {
  if (!type) return "";
  else return `on${type[0].toUpperCase()}${type.slice(1)}`;
};

export abstract class AbstractComponent<T extends object> {
  container: HTMLElement | null;
  config: TComponentConfig<T>;
  events: Array<{ type: string; callback: EventListenerOrEventListenerObject }>;

  constructor(config: TComponentConfig<T>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.container = null;
    this.events = [];
  }

  init() {
    this.container = document.createElement(
      this.config.tag as keyof HTMLElementTagNameMap,
    );
    if (this.config.className) {
      for (const className of this.config.className) {
        this.container.classList.add(className);
      }
    }

    this.events = (this.config.listeners || []).map((type) => {
      const event = toEventName(type);
      // @ts-expect-error - we need to handle both native and custom events - event handler is not defined
      let callback = this[event];
      if (!callback) {
        throw Error(`handler ${event} for ${type} is not implemented`);
      }
      callback = callback.bind(this);
      this.container!.addEventListener(type, callback);
      return { type, callback };
    });
  }

  render() {
    if (this.container) this.destroy();
    this.init();
    this.container!.innerHTML = this.toHTML();
    this.config.root.appendChild(this.container!);
    this.afterRender();
  }

  afterRender(): void {}
  destroy(): void {
    this.events.forEach(({ type, callback }) => {
      this.container!.removeEventListener(type, callback);
    });
    this.events = [];
    this.container!.remove();
  }
  toHTML(): string {
    return ``;
  }
}
