// Pure TS scratchpad. Run with: bun scratch.ts  (or `bun run scratch` for watch)
// Use this for algorithm/logic practice — no browser needed.

function sum(nums: number[]): number {
  return nums.reduce((acc, n) => acc + n, 0);
}

console.log("sum([1,2,3,4]) =", sum([1, 2, 3, 4]));
