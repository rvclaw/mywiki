const btn = document.getElementById("btn") as HTMLButtonElement;

let count = 0;
btn.addEventListener("click", () => {
  count += 1;
  btn.textContent = `count is ${count}`;
});
