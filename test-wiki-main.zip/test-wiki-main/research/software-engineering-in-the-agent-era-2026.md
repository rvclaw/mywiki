# Software engineering in the agent era (2026)

**Research date:** 5 August 2026. **Audience:** Node.js/React full-stack developers.

**Selection rule:** primary sources only (authors/publishers, universities, official engineering documentation, or first-party empirical research). The order below is a curriculum, not a popularity ranking. Items 1-6 are durable fundamentals; 7-8 are AI-era operating practice and should be rechecked periodically.

## Exact recommended order

### Timeless fundamentals

#### 1. John Ousterhout — *A Philosophy of Software Design*, 2nd ed.

**Why first / why trust it:** Ousterhout is a Stanford systems professor and built Tcl/Tk, Sprite and RAMCloud; this is the author’s official book page and the text used for his software-design course. The second edition centers complexity, deep modules, information hiding, general-purpose interfaces, and “decide what matters” rather than style trivia.[^aposd]

**Practice, do not merely read:** each week choose one production module. Write down (a) its interface surface, (b) knowledge leaked to callers, and (c) change amplification. Redesign one shallow cluster into a deeper module; record which decisions disappeared behind its interface. For React, try this on a feature boundary rather than reflexively extracting tiny hooks/components; for Node, try it around persistence, queues, or external APIs.

**Caveat:** this is a coherent, opinionated philosophy, not settled law. In particular, Ousterhout disputes parts of *Clean Code* and test-first design. Test those claims against item 2 rather than turning “deep module” into another slogan.

#### 2. MIT 6.031 — *Software Construction* (TypeScript edition)

**Why second / why trust it:** free university course materials from MIT, unusually close to this stack. The 2021 edition teaches TypeScript through static checking, testing, code review, specifications, abstract data types, representation invariants, debugging, promises, concurrency and little languages.[^mit]

**Practice:** complete readings 3–13 with exercises. For one real feature, write a behavioral contract before implementation: preconditions, postconditions, failure behavior, mutability, and examples. Partition the input space and derive tests from the partitions. Define an abstraction function and representation invariant for one nontrivial state object. During debugging, keep a hypothesis/evidence log and shrink the failing case before editing code. Review a teammate’s or agent’s diff for contract preservation, not formatting.

**Caveat:** examples predate current Node/React APIs and some material is pedagogical. Transfer the reasoning, not library choices.

#### 3. Winters, Manshreck & Wright — *Software Engineering at Google*

**Why third / why trust it:** written by Google engineers, published by O’Reilly, and legally available in full from Google’s Abseil site. It treats engineering as “programming integrated over time” and covers code review, documentation/design docs, testing, dependency management, large-scale changes, CI and delivery.[^google]

**Practice:** read chapters 1, 9–14, 18, and 21–24. Then run a four-week maintenance experiment: keep changes small; make change descriptions explain **why**; test observable behavior through public APIs; replace one brittle interaction mock with a fake or real implementation; classify tests by speed/determinism; and migrate one API incrementally while keeping main green. Measure review latency, flakes, regressions, and rollback ease.

**Caveat:** many mechanisms solve Google-scale organizational problems. Adopt the questions and economics, not necessarily monorepos, bespoke infrastructure, or Google’s ratios.

#### 4. Martin Kleppmann — *Designing Data-Intensive Applications*, 2nd ed.

**Why fourth / why trust it:** the author’s official site and O’Reilly page identify a research-grounded treatment of reliability, scalability, maintainability, data models, storage, replication, partitioning, transactions, distributed systems and derived data.[^ddia] These concepts sit underneath ordinary full-stack decisions—database constraints, caches, queues, retries and event delivery—even when React is the visible layer.

**Practice:** draw the actual write/read path for one feature from browser to database and back. Mark systems of record, derived data, consistency boundaries, retry points, idempotency keys and failure modes. Run fault drills: duplicate a message, reorder events, time out after commit, serve stale cache, and lose a worker. Write down the guarantees the product truly needs before choosing technology.

**Caveat:** this is systems reasoning, not a Node/React recipe; do not import distributed machinery into a monolith without a demonstrated need. The second edition is the current edition—older first-edition links and notes omit newer material.

#### 5. Michael Feathers — *Working Effectively with Legacy Code*

**Why fifth / why trust it:** an established Pearson/Addison-Wesley title by the author who formulated practical “seams” and characterization-testing techniques for safely changing code without adequate tests.[^feathers] It directly trains reading existing code as change-oriented investigation rather than passive line-by-line comprehension.

**Practice:** take an unfamiliar, poorly tested route/component. Start from the requested behavior or failure and trace inward using call sites, tests, logs, types and version history. Draw only the dependency slice needed for the change. Add characterization tests at a stable seam, make one small behavior-preserving refactor, then make the intended change. Compare your initial model with what the tests revealed.

**Caveat:** examples are mostly C++/Java and predate modern TypeScript tooling. Translate seams to module boundaries, dependency injection, HTTP adapters, React props/context and test doubles; avoid preserving accidental behavior merely because a characterization test captured it.

#### 6. David Agans — *Debugging: The 9 Indispensable Rules for Finding Even the Most Elusive Software and Hardware Problems*

**Why sixth / why trust it:** an engineering-method book from its author/publisher, built around reproducibility, observation, controlled experiments, divide-and-conquer, changing one thing at a time, and verifying the fix—not framework folklore.[^agans]

**Practice:** for the next five defects, ban speculative edits until you have: a reliable reproduction; a written observation separated from inference; a smallest discriminating experiment; and an explicit falsifiable hypothesis. Bisect the system boundary (browser/network/API/database), then add a regression test that fails for the original reason and remove diagnostic changes.

**Caveat:** concise and intentionally technology-neutral. Pair it with Node inspector, browser DevTools, tracing and production telemetry documentation for mechanics; those tools do not replace the method.

### Genuinely AI-era practice

#### 7. Anthropic — *Best practices for Claude Code*

**Why seventh / why trust it:** current first-party product guidance, explicitly based on Anthropic internal teams and user experience. Its central workflow is **verify; explore; plan; implement**, with scoped context, short repository instructions, early course correction, context hygiene, fresh-context reviewers and evidence rather than claims.[^claude]

**Practice:** on one medium feature, require the agent to (1) inspect relevant code without edits, (2) explain current behavior with file references, (3) propose a reviewable plan and acceptance criteria, (4) implement a small diff, (5) run typecheck/lint/unit/integration or screenshot checks, and (6) have a fresh-context agent review the diff against the plan. Put only non-obvious commands, architecture constraints and test instructions in `CLAUDE.md`/`AGENTS.md`; move deterministic rules into CI/hooks. Clear context between unrelated tasks.

**Caveat:** vendor guidance is product-specific and success-oriented. “The tests pass” is weak if the tests were inferred from the same incorrect implementation; independently derive acceptance examples from the spec and inspect the diff. Never grant broad credentials or destructive permissions merely to remove friction.

#### 8. OpenAI — *Harness engineering* + Codex execution plans; calibrate with METR

**Why eighth / why trust it:** OpenAI’s first-party 2026 report describes a real agent-written internal product and, importantly, the repository scaffolding it required: a short map instead of a giant instruction file, versioned specs/designs/plans, progressive disclosure, mechanically enforced architectural invariants, executable feedback loops, and documentation gardening.[^harness] OpenAI’s execution-plan guidance makes long work resumable through living progress, decisions, surprises and validation records.[^plans] METR’s independent empirical work is a useful counterweight: agent success rises sharply on cheaply verifiable work, while judgment and reliability remain limiting; its controlled study also found experienced developers slower on a particular set of mature-repository tasks despite believing they were faster.[^metr-risk][^metr-productivity]

**Practice:** create a small “agent-ready” slice, not a documentation empire: a short repo map; exact setup/test commands; one architecture diagram; one product spec with executable acceptance checks; and an execution plan for a multi-session change. Encode hard boundaries in types, schemas, linters, permissions and CI. Delegate bounded, reversible tasks with a clear goal, relevant context, constraints and “done when”; require command output or UI evidence. Log agent failure modes and improve the harness only when a repeated failure justifies it.

**Caveat:** OpenAI’s case study required unusual investment and explicitly says not to assume it generalizes. METR’s productivity result was a 2025 randomized study of experienced open-source developers on their own mature repositories, not a universal estimate for 2026 models, greenfield work, or beginners. Treat benchmark scores, self-reported speedups and vendor case studies as hypotheses to test locally—not labor-market forecasts.

## The compact operating model

1. **Own the problem and the contract.** State user outcome, invariants, constraints, failure behavior and acceptance evidence before generating code.
2. **Reduce cognitive load with deep boundaries.** Hide decisions; minimize knowledge crossing interfaces; optimize for the next reader and next change.
3. **Read by tracing behavior.** Start from an observable event, follow data/control through tests and history, and build the smallest sufficient model.
4. **Make change cheap and reversible.** Small diffs, seams, characterization tests, migrations, flags and rollback paths beat heroic rewrites.
5. **Debug by experiment.** Reproduce, observe, hypothesize, discriminate, fix the cause, and prove the original failure cannot recur.
6. **Turn correctness into feedback.** Types, contracts, tests, linters, builds, screenshots, telemetry and review are executable specifications—not ceremony.
7. **Use agents as bounded executors, not sources of truth.** Give them maps, tools and checks; isolate permissions; demand evidence; independently review high-impact judgment.
8. **Improve the environment, not the prompt theatrics.** Repeated agent failure usually indicates missing specification, discoverability, tooling, or enforcement. Encode durable lessons in the repository and CI.

## Sources

[^aposd]: John Ousterhout, [official *A Philosophy of Software Design* page](https://web.stanford.edu/~ouster/cgi-bin/aposd.php) (2nd ed.; page updated 26 Feb 2025).
[^mit]: MIT EECS, [6.031: Software Construction, Fall 2021](https://web.mit.edu/6.031/www/fa21/) (TypeScript readings and exercises).
[^google]: Titus Winters, Tom Manshreck & Hyrum Wright, [*Software Engineering at Google*—official full HTML edition](https://abseil.io/resources/swe-book/html/toc.html), Google/Abseil and O’Reilly.
[^ddia]: Martin Kleppmann, [official DDIA site](https://dataintensive.net/) and O’Reilly, [*Designing Data-Intensive Applications*, 2nd ed.](https://www.oreilly.com/library/view/designing-data-intensive-applications/9781098119058/).
[^feathers]: Pearson, [*Working Effectively with Legacy Code*](https://www.pearson.com/en-us/subject-catalog/p/working-effectively-with-legacy-code/P200000000161/9780131177055).
[^agans]: David J. Agans, [official *Debugging Rules* site](https://debuggingrules.com/) and O’Reilly, [book page](https://www.oreilly.com/library/view/debugging/9780814474570/).
[^claude]: Anthropic, [Best practices for Claude Code](https://code.claude.com/docs/en/best-practices) (live documentation, checked 5 Aug 2026). See also Anthropic’s first-party security case study, [How we built Claude Code auto mode](https://www.anthropic.com/engineering/claude-code-auto-mode) (25 Mar 2026).
[^harness]: OpenAI, [Harness engineering: leveraging Codex in an agent-first world](https://openai.com/index/harness-engineering/) (11 Feb 2026).
[^plans]: OpenAI Cookbook, [Codex execution plans](https://cookbook.openai.com/articles/codex_exec_plans) (live guidance, checked 5 Aug 2026). The cross-vendor instruction-file convention is documented at [AGENTS.md](https://agents.md/), now stewarded under the Linux Foundation’s Agentic AI Foundation.
[^metr-risk]: METR, [Frontier Risk Report (February–March 2026)](https://metr.org/blog/2026-05-19-frontier-risk-report/) (19 May 2026), especially evidence on cheaply verifiable coding work and limits in judgment/reliability.
[^metr-productivity]: METR, [Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity](https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/) (10 Jul 2025); use its scope and limitations, not the headline as a timeless constant.
