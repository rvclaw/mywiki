import { shoppingCart } from "./data.ts";

/*  
Use reduce() to total the groceries. 
Then find a method that will round the total to 2 decimal places.

Example output: 73.44
*/

function total(arr: typeof shoppingCart) {
  let total = arr.reduce((acc, currentVal) => {
    return acc + currentVal.price;
  }, 0);
  return total.toFixed(2);
}

console.log(total(shoppingCart));
