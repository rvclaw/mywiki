/*
   Oh no, our emoji flower bed is infested with mammals, trees and leaves!
   Without changing the API url, write a function to transform your 
   data before it's displayed. The function should eliminate
   everything but bugs and flowers. Use your function in the API call.  
   
   Hint: Be sure to console the data to see what properties can help you do this!
*/

const api =
  "https://apis.scrimba.com/emojihub/api/all/category/animals-and-nature";
let flowerBed = "";

function clearTheGarden(arr) {
  return arr.filter((item) => {
    return item.group === "plant flower" && item.group === "plant flower";
  });
}

fetch(api)
  .then((response) => response.json())
  .then((response) => clearTheGarden(response))
  .then((data) => {
    data.forEach((emoji) => {
      flowerBed += `<li>${emoji.htmlCode}</li>`;
      console.log(`<li>${emoji.name}</li>`);
    });
  })
  .catch((err) => console.log(err));

console.log(flowerBed);
