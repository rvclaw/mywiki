/* 
Scrimba mascot Pumpkin has won the grand prize at an international 
cat show. Below are Pumpkin's scores from the judges, as well as all the 
prizes he's won. In all the excitement of victory,
they've become a jumbled mess of nested arrays. Let's 
help Pumpkin by sorting it out. 

Write a function to flatten nested arrays of strings or
numbers into a single array. There's a method
for this, but pratice both doing it manually and using the method. 

Example input: [1, [4,5], [4,7,6,4], 3, 5]
Example output: [1, 4, 5, 4, 7, 6, 4, 3, 5]
*/

function flatten(arr: unknown[]) {
  const newArr: unknown[] = [];
  arr.forEach((item) => {
    if (Array.isArray(item)) {
      newArr.push(...flatten(item));
      //   item.forEach((element) => {
      //     newArr.push((element));
      //   });
    } else {
      newArr.push(item);
    }
  });
  return newArr;
}

console.log(flatten([1, [4, 5], [4, 7, 6, 4, [4, 5]], 3, 5]));
