import { podcasts3 } from "./data.ts";

/* Night at the Scrimbies 

It's time for the Scrimbies, a prestigious award show for podcast hosts.
We need to assemble a list of podcast hosts so we can start handing out awards. 

Write a function that takes in the podcast data and
returns a flat array of podcast hosts. There are quite a few ways to approach
this, but try solving the problem using reduce(). 

Once you have a flat array of hosts, write a second function to randomly assign each host a prize
from the awards array. 

Example output: ["🏆 Alex Booker", "⭐ Bob Smith", "💎 Camilla Lambert" ...] 

*/
const awards = ["🏆", "⭐", "💎", "🥇", "👑"];

function getHosts(data: typeof podcasts3) {
  return data.reduce<string[]>((acc, curr) => {
    return [...acc, ...curr.hosts];
  }, []);
}

function assignAwards(data: typeof podcasts3) {
  let hosts = getHosts(data);
  return hosts.map((host) => {
    let randIndex = Math.floor(Math.random() * awards.length);

    return `${awards[randIndex]} ${hosts[randIndex]}`;
  });
}

console.log(getHosts(podcasts3));
console.log(assignAwards(podcasts3));
