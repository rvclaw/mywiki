# Teaching notes

- The user is a Node.js full-stack developer.
- Abstract data-structure explanations do not stick without a real application challenge.
- Prefer projects using familiar backend concepts, APIs, databases, search, and the user's own data.
- Teach the production structure alongside the learning structure—for example, a hand-written BST for the invariant, followed by SQLite's B-tree index for real-world use.
- The user wants durable understanding they can reconstruct later, not short-term recognition while watching a course. Use prediction, drawing, blank-file implementation, explanation, and spaced retrieval.
- Avoid parallel course-hopping. Keep Scrimba as the current spine and use narrowly matching sections from other courses only after an attempted Scrimba challenge.
- The user previously failed an interview assessment involving basic DSA and React. React preparation should optimize for producing working code from a blank file under a time limit, then testing user-visible behavior—not for accumulating more advanced React articles.
