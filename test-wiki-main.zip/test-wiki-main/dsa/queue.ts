export class Queue<T = unknown> {
  #queue: T[];

  constructor() {
    this.#queue = [];
  }
  enqueue(element: T) {
    this.#queue.push(element);
  }

  dequeue() {
    if (this.isEmpty()) {
      throw new Error("Queue is empty.");
    }
    return this.#queue.shift();
  }

  peek() {
    if (this.isEmpty()) {
      throw new Error("Queue is empty.");
    }
    return this.#queue[0];
  }

  size() {
    return this.#queue.length;
  }

  isEmpty() {
    return this.#queue.length === 0;
  }
}
