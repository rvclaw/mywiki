/// <reference types="node" />

import assert from "node:assert/strict";
import { describe, test } from "node:test";
import { isValid } from "./expression_validation.ts";

describe("isValid", () => {
  test("validates a valid simple expression", () => {
    const exp = "< 1 + 2 > * 5";
    const result = true;
    assert.strictEqual(isValid(exp), result);
  });

  test("validates a valid complex expression", () => {
    const exp = "<<1 + 2> * 5> + <6 + 7>";
    const result = true;
    assert.strictEqual(isValid(exp), result);
  });

  test("validates an invalid simple expression", () => {
    const exp = "<<1 + 2> * 9";
    const result = false;
    assert.strictEqual(isValid(exp), result);
  });

  test("validates an invalid complex expression", () => {
    const exp = "<<1 + 2>> * 5> + <6 + 7>";
    const result = false;
    assert.strictEqual(isValid(exp), result);
  });

  test("validates an invalid expression that starts with a closing bracket", () => {
    const exp = "><1 + 2>> * 5 + <6 + 7>";
    const result = false;
    assert.strictEqual(isValid(exp), result);
  });

  test("validates an invalid expression of just one opening bracket", () => {
    const exp = "<";
    const result = false;
    assert.strictEqual(isValid(exp), result);
  });

  test("validates an invalid expression of just one closing bracket", () => {
    const exp = ">";
    const result = false;
    assert.strictEqual(isValid(exp), result);
  });

  test("validates an empty expression", () => {
    const exp = "";
    const result = true;
    assert.strictEqual(isValid(exp), result);
  });
});
