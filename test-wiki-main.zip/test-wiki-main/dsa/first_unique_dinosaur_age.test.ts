/// <reference types="node" />

import assert from "node:assert/strict";
import { describe, test } from "node:test";
import { findFirstUniqueDinosaurAge } from "./first_unique_dinosaur_age.ts";

describe("findFirstUniqueDinosaurAge", () => {
  test("finds the first unique age early in the stream", () => {
    const ages = [12, 14, 12, 12, 16, 15, 16, 17, 16, 12];
    const result = 14;
    assert.strictEqual(findFirstUniqueDinosaurAge(ages), result);
  });

  test("finds the first unique age later in the stream", () => {
    const ages = [14, 16, 16, 14, 17, 18, 19];
    const result = 17;
    assert.strictEqual(findFirstUniqueDinosaurAge(ages), result);
  });

  test("finds no unique age", () => {
    const ages = [14, 16, 14, 14, 16, 14, 14];
    const result = "No unique age was found.";
    assert.strictEqual(findFirstUniqueDinosaurAge(ages), result);
  });
});
