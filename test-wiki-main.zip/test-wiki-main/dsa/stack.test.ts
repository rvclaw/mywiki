/// <reference types="node" />

import assert from "node:assert/strict";
import { beforeEach, describe, test } from "node:test";
import { Stack } from "./stack.ts";

describe("Stack", () => {
  let stack: Stack;

  beforeEach(() => {
    stack = new Stack();
  });

  test("performs a number of valid push and pop operations", () => {
    stack.push(1);
    stack.push(2);
    stack.push(3);
    stack.push(4);
    stack.push(5);
    const popped = stack.pop();
    assert.strictEqual(popped, 5);
  });

  test("performs push and pop operations and peeks at the top of the stack", () => {
    stack.push(1);
    stack.push(2);
    stack.push(3);
    stack.pop();
    assert.strictEqual(stack.peek(), 2);
  });

  test("performs push and pop operations and checks size", () => {
    stack.push(1);
    stack.push(2);
    stack.pop();
    assert.strictEqual(stack.size(), 1);
  });

  test("performs push and pop operations and checks if empty and it is not", () => {
    stack.push(1);
    stack.push(2);
    stack.pop();
    assert.strictEqual(stack.isEmpty(), false);
  });

  test("performs push and pop operations and checks if empty and it is", () => {
    stack.push(1);
    stack.pop();
    assert.strictEqual(stack.isEmpty(), true);
  });

  test("tries to pop from an empty stack", () => {
    assert.throws(() => stack.pop(), { message: "Stack is empty." });
  });

  test("tries to peek at the top of an empty stack", () => {
    assert.throws(() => stack.peek(), { message: "Stack is empty." });
  });
});
