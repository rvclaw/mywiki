import { findAllPalindromes as findAllPalindromes } from "./palindrome.ts";
import test from "node:test";
import assert from "node:assert/strict";

test("findAllPalindromes", (t) => {
  t.test("array of length 3 gets 3 palindromes", () => {
    const usernames = ["TriciRT", "TREX1xerT", "VeloOLEv"];
    const result = ["TriciRT", "TREX1xerT", "VeloOLEv"];
    assert.deepStrictEqual(findAllPalindromes(usernames), result);
  });

  t.test("array of length 4 gets 2 palindromes", (t) => {
    const usernames = ["Tricer66", "TREXerT", "Veloc1COLEv", "stego95"];
    const result = ["TREXerT", "Veloc1COLEv"];
    assert.deepStrictEqual(findAllPalindromes(usernames), result);
  });

  t.test("array of length 2 gets no palindromes", (t) => {
    const usernames = ["nigersaurus111", "BRACHI33"];
    const result: unknown[] = [];
    assert.deepStrictEqual(findAllPalindromes(usernames), result);
  });

  t.test("empty array gets no palindromes", (t) => {
    const usernames: string[] = [];
    const result: unknown[] = [];
    assert.deepStrictEqual(findAllPalindromes(usernames), result);
  });
});
