/**
 * Find the age range by tracking the smallest and largest age in one pass.
 * Time: O(n)
 * Space: O(1)
 */
export function getAgeRange(ages: number[]) {
  let minAge = ages[0];
  let maxAge = ages[0];

  for (const age of ages) {
    if (age < minAge) {
      minAge = age;
    }

    if (age > maxAge) {
      maxAge = age;
    }
  }

  return maxAge - minAge;
}
