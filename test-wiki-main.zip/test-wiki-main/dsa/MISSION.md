# Mission: Data Structures & Algorithms for Coding Interviews

## Why
The user is preparing for technical coding interviews. They want to *understand*
algorithms deeply enough to re-derive them under pressure — not memorize code that
evaporates the moment the interviewer changes the question.

## Success looks like
- Can explain, from a mental model (not memory), how a sorting algorithm works and why.
- Can implement bubble sort from scratch on a whiteboard in a few minutes.
- Can state time/space complexity, stability, and in-place-ness of common algorithms and *justify* them.
- Can recognize when a given algorithm is the right (or wrong) tool in an interview.

## Constraints
- Wants intuition-first teaching: "explain it so I can forget the algorithm and re-derive it."
- Working in a TypeScript workspace (`dsa/`) with runnable practice files.

## Out of scope (for now)
- Advanced/exotic sorts (radix, timsort internals) until the O(n²) family is solid.
- Language-specific trivia unrelated to interview problem-solving.
