/// <reference types="node" />

import assert from "node:assert/strict";
import { beforeEach, describe, test } from "node:test";
import { Queue } from "./queue.ts";

describe("Queue", () => {
  let queue: Queue<number>;

  beforeEach(() => {
    queue = new Queue<number>();
  });

  test("performs a number of valid enqueue and dequeue operations", () => {
    queue.enqueue(1);
    queue.enqueue(2);
    queue.enqueue(3);
    queue.enqueue(4);
    queue.enqueue(5);
    const dequeued = queue.dequeue();
    assert.strictEqual(dequeued, 1);
  });

  test("performs enqueue and dequeue operations and peeks at the front of the queue", () => {
    queue.enqueue(1);
    queue.enqueue(2);
    queue.enqueue(3);
    queue.dequeue();
    assert.strictEqual(queue.peek(), 2);
  });

  test("performs enqueue and dequeue operations and checks size", () => {
    queue.enqueue(1);
    queue.enqueue(2);
    queue.dequeue();
    assert.strictEqual(queue.size(), 1);
  });

  test("performs enqueue and dequeue operations and checks if empty and it is not", () => {
    queue.enqueue(1);
    queue.enqueue(2);
    queue.dequeue();
    assert.strictEqual(queue.isEmpty(), false);
  });

  test("performs enqueue and dequeue operations and checks if empty and it is", () => {
    queue.enqueue(1);
    queue.dequeue();
    assert.strictEqual(queue.isEmpty(), true);
  });

  test("tries to dequeue from an empty queue", () => {
    assert.throws(() => queue.dequeue(), { message: "Queue is empty." });
  });

  test("tries to peek at the front of an empty queue", () => {
    assert.throws(() => queue.peek(), { message: "Queue is empty." });
  });
});
