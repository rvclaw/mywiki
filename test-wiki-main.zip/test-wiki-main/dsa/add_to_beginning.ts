import { Node } from "./node.ts";

export function addToBeginning(head, value) {
  const node = new Node(value);
  node.next = head;
  return node;
}
