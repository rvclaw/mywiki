# DSA for Coding Interviews — Resources

## Knowledge

- [Data Structures and Algorithms — Scrimba](https://scrimba.com/data-structures-and-algorithms-c0shn6ckdm)
  The user's active 2.5-hour JavaScript course. Its current sequence is Trees → Binary Search Trees → BST Search challenge → DFS/BFS → Graphs → two graph challenges. Use lesson 0006 for retrieval practice and durable mental models around this compressed section.
- [Complete Intro to Computer Science — Brian Holt](https://master.dev/courses/computer-science-v2/)
  The best targeted deepening course after Scrimba: JavaScript exercises for BSTs, AVL balancing, DFS/BFS tree traversals, graph representation, pathfinding, and tries. Use only the matching section after completing the corresponding Scrimba challenge.
- [The Last Algorithms Course You'll Need — ThePrimeagen](https://master.dev/courses/algorithms/)
  A 9-hour JavaScript/TypeScript implementation course with substantial tree search, heaps, graphs, maps, and LRU practice. Use later for a second implementation from memory, not concurrently with Scrimba.
- [Practical Problem Solving with Algorithms — Kyle Simpson](https://master.dev/courses/algorithms-practice/)
  A 9-hour JavaScript course built around four working projects rather than isolated DSA drills. Best fit for the user's practical learning preference: recursion and indexing through a periodic-table speller, Maps through chessboard diagonals, graph traversal and dynamic programming through Knight's Dialer, and tries/DAWGs through a word unscrambler. Use the user's bookmarked [course slides](https://static.frontendmasters.com/assets/courses/2023-04-10-algorithms-practice/algorithms-practice-slides.pdf) and [Periodic Table starter repository](https://github.com/getify/workshop-periodic-table/tree/option-1) while practicing.
- [Computer Science Fundamentals — Brilliant](https://brilliant.org/courses/computer-science-algorithms/?from_llp=computer-science)
  An interactive fundamentals supplement with 39 lessons and 156 exercises covering arrays, binary search, sorting, complexity, stable matching, decision trees, and graphs. Use for visual intuition and retrieval practice—not as the main practical path, because it uses pseudocode-style exercises rather than Node.js projects and does not list trees/BSTs in its curriculum.
- [Bubble sort — Wikipedia](https://en.wikipedia.org/wiki/Bubble_sort)
  Authoritative summary: complexity table (worst/avg O(n²), best O(n)), stability, adaptivity, optimized pseudocode. Use for: precise complexity claims and the early-exit optimization.
- [Introduction to Algorithms (CLRS) — Cormen, Leiserson, Rivest, Stein](https://mitpress.mit.edu/9780262046305/introduction-to-algorithms/)
  The canonical algorithms textbook. Use for: rigorous proofs of correctness and complexity when depth is needed.
- [Bubble Sort — GeeksforGeeks](https://www.geeksforgeeks.org/dsa/bubble-sort-algorithm/)
  Practical walkthrough + [interview Q&A](https://www.geeksforgeeks.org/dsa/top-interview-questions-and-answers-on-bubble-sort/). Use for: common interview question phrasings.
- [Animated Sorting Algorithms: Bubble Sort](https://web.archive.org/web/20150303084352/http://www.sorting-algorithms.com/bubble-sort)
  Visual demonstration. Use for: building the "bubbling up" mental picture.
- [Overview of merge sort — Khan Academy (with Thomas Cormen)](https://www.khanacademy.org/computing/computer-science/algorithms/merge-sort/a/overview-of-merge-sort)
  Intuition-first walkthrough of divide-and-conquer + the linear merge. **Primary source** for the merge sort lessons.
- [Merge sort — Wikipedia](https://en.wikipedia.org/wiki/Merge_sort)
  Complexity table (O(n log n) all cases), stability, O(n) space, top-down vs bottom-up. Use for: precise claims.
- [VisuAlgo — Sorting (merge sort)](https://visualgo.net/en/sorting)
  Step-by-step animation of the split/merge recursion. Use for: watching the merge happen live.

### Binary search trees

- [MIT 6.006 — Lecture 5: Binary Search Trees, BST Sort](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-fall-2011/resources/lecture-5-binary-search-trees-bst-sort/)
  University lecture on the BST ordering invariant, search, insertion, traversal, and why tree height controls performance. **Primary source** for the BST lesson.
- [Cornell CS 2110 — Binary Search Trees](https://www.cs.cornell.edu/courses/cs2110/2026sp/lectures/lec17/)
  Detailed explanation of the order invariant, pruning during search, in-order traversal, and self-balancing trees. Use for: checking the mental model and complexity claims.
- [MDN — `Map`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map)
  Authoritative JavaScript reference. A `Map` iterates in insertion order, not sorted-key order; use it to contrast exact key lookup with ordered-tree operations.
- [Why databases use ordered indexes but programming uses hash tables](https://www.evanjones.ca/ordered-vs-unordered-indexes.html)
  From the user's bookmarks. Connects in-memory `Map` lookups to database B-tree indexes and explains why range and prefix queries need ordering.
- [SQLite Internals: Pages & B-trees](https://fly.io/blog/sqlite-internals-btree/)
  From the user's bookmarks. A concrete walkthrough of pages splitting and a B+tree locating records in a real database.
- [Use The Index, Luke](https://use-the-index-luke.com/)
  From the user's bookmarks. Practical SQL indexing and query-performance guide for application developers.
- [Let's build a Full-Text Search Engine](https://artem.krylysov.com/blog/2020/07/28/lets-build-a-full-text-search-engine/)
  From the user's bookmarks. A project tutorial using an inverted index; written in Go but directly adaptable to TypeScript.
- [Build a Maze Solver Using Graphs](https://realpython.com/python-maze-solver/)
  From the user's bookmarks. A full visual project showing nodes, edges, weights, and shortest paths; written in Python but adaptable to TypeScript.

### Trees and graphs in real software

- [VisuAlgo — Graph Traversal (DFS/BFS)](https://visualgo.net/en/dfsbfs)
  Interactive animations and e-lecture from Associate Professor Steven Halim's team at the National University of Singapore. It explicitly starts with preorder/inorder/postorder binary-tree traversal, then shows what changes for general graphs: arbitrary neighbors, cycles, visited state, DFS/BFS, paths, and applications. **Best first resource for visual intuition.**
- [MIT 6.006 — Lecture 6: Binary Trees, Part 1](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/resources/lecture-6-binary-trees-part-1/)
  Erik Demaine's undergraduate lecture on tree terminology, recursive inorder traversal, navigation, dynamic operations, and tree applications. Use after visualization to make the reasoning and complexity precise.
- [MIT 6.006 — Lecture 10: Depth-First Search](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/resources/lecture-10-depth-first-search/)
  Justin Solomon's undergraduate lecture covering full DFS, topological sorting, and cycle detection. Use as the rigorous graph-DFS follow-up rather than watching the complete course.
- [MDN — Introduction to the DOM](https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model/Introduction)
  Authoritative browser documentation: HTML is parsed into a logical tree whose nodes JavaScript traverses and mutates. Best first practical tree because it is already part of full-stack work.
- [Pro Git — Git Objects](https://git-scm.com/book/en/v2/Git-Internals-Git-Objects)
  Official Git book chapter with runnable plumbing commands. Directories become tree objects, files become blobs, and commits point to parent commits to form an object graph.
- [PostgreSQL — Index Types](https://www.postgresql.org/docs/current/indexes-types.html)
  Official documentation showing exactly why B-tree ordering supports equality, ranges, `BETWEEN`, prefix matching, and sorted results while a hash index supports equality only.
- [CodeMirror's document representation](https://marijnhaverbeke.nl/blog/codemirror-line-tree.html)
  CodeMirror's author explains replacing a flat line array with a B-tree so a JavaScript editor can locate lines by number or screen position and handle bulk edits efficiently.
- [typescript-eslint parser](https://typescript-eslint.io/packages/parser/)
  Maintainer documentation explaining how TypeScript source is converted into an ESTree-compatible abstract syntax tree for ESLint traversal.
- [Bazel Query Guide](https://bazel.build/query/guide)
  Official build-system guide showing dependency-graph operations in production: transitive dependencies, reverse dependencies, paths, graph visualization, and build ordering.

### Build-along tree and graph projects

- [Software Design by Example in JavaScript](https://third-bit.com/sdxjs/)
  A free project-based book by Greg Wilson (Software Carpentry co-founder and ACM SIGSOFT Influential Educator Award recipient). Builds small versions of real developer tools with tested JavaScript. The most relevant sequence is Parsing Expressions (AST tree) → Build Manager (dependency DAG, cycle detection, topological sort) → Layout Engine (DOM/layout tree) → Module Bundler (AST traversal and transitive dependency graph) → Package Manager (constraint search tree). Best overall follow-up after Scrimba.
- [500 Lines or Less — Dagoba: An In-Memory Graph Database](https://aosabook.org/en/500L/dagoba-an-in-memory-graph-database.html)
  A complete JavaScript graph database in under 500 lines from the Architecture of Open Source Applications series. Builds vertices, directed edges, indexes, lazy graph traversal queries, serialization, and persistence.
- [The Super Tiny Compiler](https://github.com/jamiebuilds/the-super-tiny-compiler)
  A heavily annotated, runnable JavaScript compiler in one file. Tokenizes source, builds an abstract syntax tree, traverses/transforms that tree, and generates output; tests run with `node test.js`.
- [An Interactive Introduction to Quadtrees](https://growingswe.com/blog/quadtrees)
  Visual, executable tutorial covering insertion, subdivision, point/range/nearest-neighbor queries, pruning, collision detection, and image compression. Code examples use Python but the model ports directly to TypeScript and Canvas.
- [Web Browser Engineering](https://browser.engineering/)
  A free, project-based book that builds a browser and includes constructing an HTML tree, laying out that tree, applying CSS, handling links, and making the DOM scriptable. Python and substantially larger than a single lesson.
- [Implementing a B-Tree in Go](https://www.cloudcentric.dev/implementing-a-b-tree-in-go/)
  A focused implementation article with companion source. Useful after plain BSTs are comfortable; porting insertion and node splitting to TypeScript is an advanced exercise.

### React interview practice

- [Thinking in React](https://react.dev/learn/thinking-in-react)
  The official React workflow for turning a prompt into an implementation: identify the component hierarchy, render a static version, choose minimal state, place state at the closest common owner, and add inverse data flow. **Primary source** for timed React implementation practice.
- [React Testing Library — Introduction](https://testing-library.com/docs/react-testing-library/intro/)
  Official testing guidance built around user-visible behavior rather than component internals. Use with Vitest and `user-event` after each interview-sized component.
- [Senior-Level Frontend Interview Preparation](https://master.dev/courses/interviewing-frontend-v2/)
  From the user's bookmarks. An advanced, 80%-hands-on workshop whose challenges are verified by tests. Use selectively: Accordion, Tabs, Dialog, Data Table, and recursive Reddit Thread are high-return React exercises; the extreme portfolio, ChatGPT, and spreadsheet projects can wait.
- [Complete Intro to React v9](https://react-v9.holt.courses/)
  From the user's bookmarks. Use as a lookup when a timed attempt exposes a specific fundamentals gap. Do not restart the whole course merely to feel prepared.
- [React TypeScript Cheatsheets](https://react-typescript-cheatsheet.netlify.app/)
  From the user's bookmarks. Quick reference for component props, events, hooks, and React utility types while reviewing an attempt—not during the timed attempt.
- [How to fetch data in React with performance in mind](https://www.developerway.com/posts/how-to-fetch-data-in-react)
  From the user's bookmarks. Turn its loading, error, waterfall, and race-condition cases into a later async UI exercise. Read after basic state and interaction reps are reliable.

### Engineering a subscription-based React store

- [Redux: Implementing Store from Scratch — Dan Abramov](https://egghead.io/lessons/react-redux-implementing-store-from-scratch)
  A three-minute implementation by Redux's creator that exposes the framework-independent core: a closure holds state and listeners; dispatch calculates the next state; subscribe returns unsubscribe. **Best first mental model.**
- [React — `useSyncExternalStore`](https://react.dev/reference/react/useSyncExternalStore)
  The authoritative contract for connecting an external mutable source to React. Covers stable subscriptions, immutable/cached snapshots, `Object.is`, cleanup, SSR/hydration, transitions, and common infinite-render mistakes. **Primary correctness source.**
- [React 18 Working Group — `useMutableSource` → `useSyncExternalStore`](https://github.com/reactwg/react-18/discussions/86)
  Design rationale from the React team and state-library maintainers: tearing, synchronous external updates, referentially stable snapshots, selectors, and why implementing concurrent-safe subscriptions in userland is difficult. Read after the basic store works.
- [Zustand source — vanilla store](https://github.com/pmndrs/zustand/blob/main/src/vanilla.ts) and [React binding](https://github.com/pmndrs/zustand/blob/main/src/react.ts)
  Minimal production TypeScript showing a deep module boundary: the store is independent of React, while a very small adapter binds `subscribe` and snapshots to React. Read source after writing a first version, not before.
- [Redux Store API](https://redux.js.org/api/store)
  Production-grade subscription semantics and edge cases, including unsubscribe behavior, listener snapshots during dispatch, nested dispatch, and why listeners pull current state instead of receiving every intermediate value.
- [Our Own React Global State Manager in Less Than 50 Lines](https://gitnation.com/contents/our-own-react-global-state-manager-in-less-than-50-lines-of-code)
  From the user's bookmarks. A useful modern build-along covering a vanilla store, listeners, selectors, and `useSyncExternalStore`, but explicitly a teaching implementation without production features such as debugging and robust equality handling.

### Recursion & the call stack (for understanding the recursive part of merge sort)

- [Python Tutor — code visualizer](https://pythontutor.com/visualize.html)
  Supports JavaScript. Step forward/back and watch stack frames push/pop, each with its own locals. **Best tool** for "where is it stored / when does merge run" — paste the JS mergeSort and step through it.
- [Computerphile — "What on Earth is Recursion?" (Prof. Brailsford)](https://www.youtube.com/watch?v=Mv9NEXX1VHc)
  9-min intuition builder; the follow-up "EXTRA BITS: Recursion and the Stack" covers the call stack directly.
- [Computerphile — "Programming Loops vs Recursion"](https://www.youtube.com/watch?v=HXNhEYqFo0o)
  Why recursion works and how the stack drives it.
- [Khan Academy — Recursion (with Thomas Cormen)](https://www.khanacademy.org/computing/computer-science/algorithms/recursive-algorithms/a/recursion)
  High-trust article; ties recursion straight into merge sort.
- [Stack Overflow — "Understanding the Recursion of mergesort"](https://stackoverflow.com/questions/19072004/understanding-the-recursion-of-mergesort)
  Top answer explains the "recursive leap of faith" — assume mergeSort already works, then just split + merge.
- [How to Understand Recursion (Not Just Memorize It)](https://www.codeintuition.io/blogs/how-to-understand-recursion)
  The frames-on-a-stack tracing method, walked through level by level.

### Low-level: how a function call works in hardware (the "where is it stored" layer)

- [Berkeley CS161 — x86 Assembly & the Call Stack](https://textbook.cs161.org/memory-safety/x86.html)
  **Best read for the hardware layer.** All 11 steps of a call/return with stack diagrams: push args, save return address (eip), save frame pointer (ebp), allocate locals, prologue/epilogue. Use for: understanding physically where frames + return values live.
- [Harvard CS61 — Calling Convention](https://cs61.seas.harvard.edu/site/2018/Asm2/)
  x86-64 version: stack grows down, %rsp/%rbp, red zone, entry/exit sequences.
- [Wikipedia — x86 calling conventions](https://en.wikipedia.org/wiki/X86_calling_conventions)
  Reference for cdecl / System V / Microsoft x64 arg passing and cleanup.
- [Nand2Tetris](https://www.nand2tetris.org/) (free course + book)
  Deepest intuition: build a stack machine that implements function calls from logic gates up (Project 8 = function call → stack frame).

### Merge sort — gold-standard lecture

- [MIT 6.006 — Lecture 3: Insertion Sort, Merge Sort](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-fall-2011/resources/lecture-3-insertion-sort-merge-sort/) ([video](https://www.youtube.com/watch?v=Kg4bqzAqRBM))
  Analyzes merge sort with a **recursion tree** — the canonical way to see why it's O(n log n). Best single lecture for the interview mission.
- [MIT 6.006 lecture 3 notes (PDF)](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/6d1ae5278d02bbecb5c4428928b24194_MIT6_006S20_lec3.pdf)
  Solves T(n) = 2T(n/2) + Θ(n) two ways (substitution + recurrence tree).

### Suggested order (for this mission)

Python Tutor (see the stack, ~15 min) → Computerphile "What on Earth is Recursion?" (~10 min) → MIT 6.006 Lecture 3. Dip into Berkeley CS161 only when you want the true hardware-level answer to "where is it stored."

## Wisdom (Communities)

- [r/leetcode](https://reddit.com/r/leetcode) — high-volume interview-prep community. Use for: pacing, what companies actually ask, mock-interview partners.
- [NeetCode Roadmap](https://neetcode.io/roadmap) — structured problem set with a strong community. Use for: what to practice next after fundamentals.

## Gaps
- The bookmark collection contains many advanced React internals and performance articles but almost no direct component-testing practice. Use the official Testing Library material rather than filling this gap with another large course.
