/// <reference types="node" />

import assert from "node:assert/strict";
import { beforeEach, describe, test } from "node:test";
import { Node } from "./node.ts";
import { insert } from "./insert.ts";
import { search } from "./search.ts";

describe("search", () => {
  let root;

  beforeEach(() => {
    root = new Node(6);
    insert(root, 4);
    insert(root, 8);
    insert(root, 3);
    insert(root, 5);
    insert(root, 7);
    insert(root, 9);
    insert(root, 1);
  });

  test("finds the value 5 in the tree", () => {
    const target = 5;
    assert.ok(search(root, target));
  });

  test("doesn't find the value 15 in the tree", () => {
    const target = 15;
    assert.ok(!search(root, target));
  });

  test("doesn't find the value 15 in an empty tree", () => {
    root = null;
    const target = 15;
    assert.ok(!search(root, target));
  });
});
