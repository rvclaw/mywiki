let palindorme = "racecar"

function checkPalindrome(str) {

    for (let i = 0; str.length; i++) {

    }

}

